
# setup
library(pbapply)
library(stringr)
library(tidyverse)
library(grf)
packageVersion("grf")
library(rpart)
library(optparse)

Sys.time()

option_list <- list(
	make_option("--sample_size", default=500),
	make_option("--rep", default=1)
)
opts <- parse_args(OptionParser(option_list=option_list))
sample_size <- as.numeric(opts$sample_size)
rep <- as.numeric(opts$rep)
seed <- read_rds("/storage/home/jpx5053/work/research/grf_mediation/workingdata/random_seeds.rds")
seed <- seed[[rep]]
print(sprintf("Sample size is %s",sample_size))
print(sprintf("seed is %s",rep))
print(sprintf("replicate is %s",rep))

print("=========================================")
print("Case 1")
print("=========================================")

.Random.seed = seed
N = sample_size
x1 = runif(N,-1,1)
x2 = runif(N,-1,1)
x3 = runif(N,-1,1)
x4 = runif(N,-1,1)
x5 = runif(N,-1,1)
x6 = runif(N,-1,1) # heterogeneity variable

hnde = case_when(x6 > 0 & x6<0.6 ~ x6, 
                x6 >=0.6~ -x6,
                TRUE ~ 3*x6)
hnie = rep(.5,N)

err1 = rnorm(N, 0, 1) # for Y
err2 = rnorm(N, 0, 1) # for mediator (college completion)

# covariates
X = cbind(x1, x2, x3, x4, x5, x6)
# treatment
a <- Vectorize(function(x) {
    d0 = data.frame(c1 = x1[x]*x2[x], c2 = x3[x]*x4[x]*x5[x], 
                    c3 = sin(x1[x])*sin(x2[x]), c4 = sin(x3[x])*sin(x4[x])*sin(x5[x]))
    d1 = data.frame(a1 = sin(d0$c1 + d0$c2), a2 = sin(d0$c2), a3 = d0$c3, a4 = d0$c4)
    d2 = 0.5*sin(d1$a1 + d1$a2) + 0.5*(d1$a3 + d1$a4)
    1/( 1 + exp(-d2) )
}, vectorize.args = "x")
A <- rbinom(N, size = 1, prob = a(1:N))

# mediator
mx = 4*(sin(3*x1)+sin(3*x2)+sin(3*x3)+sin(3*x4)+sin(3*x5))
theta_ma = 1
m <- function(ia=A,x) {
    l1 = theta_ma*ia[x] + mx[x] + err2[x]    
    ifelse(ia[x] == 0, 0, as.numeric(l1 > 6))
}
M = m(ia=A,1:N)
table(A,M)

# outcome
y0 = data.frame(x1 = sin(x1+x2), x2 = sin(x3+x4+x5), x3 = sin(x1+x2+x3+x4+x5))
y1 = data.frame(x1 = sin(y0$x1 + y0$x2), x2 = y0$x3)
y2 = 2*sin(y1$x2 + y1$x2)
Y = hnde*A + hnie*M + y2 + err1

# TRUE
MA = Vectorize(function(x) {m(ia=A,x)*hnie[x]},vectorize.args = "x")
M1 = Vectorize(function(x) {m(ia=rep(1,N),x)*hnie[x]},vectorize.args = "x")
M0 = Vectorize(function(x) {m(ia=rep(0,N),x)*hnie[x]},vectorize.args = "x")

cat("tot")
mean(hnde+(M1(1:N)-M0(1:N)))
cat("nde")
mean(hnde)
cat("nie")
mean(M1(1:N)-M0(1:N))

# total effect
cf = causal_forest(X,Y,A)
average_treatment_effect(cf)
cf$predictions %>% mean

# ## no clever variable
# med = med_causal_forest(X,Y,W = as.factor(A),M = as.vector(M),num.trees=4000,min.node.size=20)
# med_summary_effect(med)
# med$nde %>% mean
# med$nie %>% mean
# med$nde %>% summary
# med$nie %>% summary

source("/storage/home/jpx5053/work/research/grf_mediation/codes/Lrnr_regressionforest.R")
df_full = data.frame(Y = Y, x1 = x1, x2 = x2, x3 = x3, x4 = x4, x5 = x5,x6=x6, A = A, M = M)
df_full$weight = 1
df_full$id = 1:N
xvars <- rlang::exprs(x1,x2,x3,x4,x5,x6)
source("/storage/home/jpx5053/work/research/grf_mediation/codes/Zhou_simulaltioncodes_add_continuous.R")
overall


main_df = main_df %>% arrange(id)
med = med_causal_forest(X,Y,W = as.factor(A),M = as.vector(M),                        
                        num.trees=4000,min.node.size=20)
med_summary_effect(med)
med$nde %>% mean
med$nie %>% mean
med$nde %>% summary
med$nie %>% summary

# ==========================================================
# combine information from grf and dml
# ==========================================================
df = data.frame(id = 1:N,
            ax1 = x6,
            true_ate = hnde + (M1(1:N)-M0(1:N)), true_nde = hnde, 
            true_nie = M1(1:N)-M0(1:N), 
            est_ate = cf$predictions, est_nde = med$nde,                 
            est_nie = med$nie)
df_hte = left_join(df,main_df %>% select(id,ate_eif,tde_eif, tie_eif,cde_eif,nie_eif)) %>% arrange(id) # mixed grf results and dml results


# ==========================================================
# point-wise comparison
# ==========================================================
# GRF method
# Use Population Truth for coverage calculation
# NDE is same as Case 3: -0.82
true_nde <- -0.82
true_unit_nie <- M1(1:N)-M0(1:N)
# NIE from MC simulation: 0.11404
true_nie <- 0.11404
true_ate <- true_nde + true_nie


med_sum <- med_summary_effect(med)

nde_hat <- as.numeric(med_sum["Natural Direct Effect","estimate"])
nde_se <- as.numeric(med_sum["Natural Direct Effect","std.err"])
nie_hat <- as.numeric(med_sum["Natural Indirect Effect","estimate"])
nie_se <- as.numeric(med_sum["Natural Indirect Effect","std.err"])
ate_hat <- average_treatment_effect(cf)["estimate"]
ate_se <- average_treatment_effect(cf)["std.err"]

ate_unit_rmse <- sqrt(mean((as.numeric(cf$predictions) - hnde - true_unit_nie)^2, na.rm = TRUE))
ate_unit_corr <- suppressWarnings(stats::cor(as.numeric(cf$predictions), hnde + true_unit_nie, use = "complete.obs"))
nde_unit_rmse <- sqrt(mean((med$nde - hnde)^2, na.rm = TRUE))
nde_unit_corr <- suppressWarnings(stats::cor(med$nde, hnde, use = "complete.obs"))
nie_unit_rmse <- sqrt(mean((med$nie - true_unit_nie)^2, na.rm = TRUE))
nie_unit_corr <- suppressWarnings(stats::cor(med$nie, true_unit_nie, use = "complete.obs"))

# for dml summarization
## simple linear projection
fit_ate = lm(df_hte$ate_eif ~ X)$fitted.value 
fit_nde = lm(df_hte$tde_eif ~ X)$fitted.value
fit_nie = lm(df_hte$tie_eif ~ X)$fitted.value 
## nonparametric tree structure
dml_ate_tree = rpart(as.formula(paste0("df_hte$ate_eif ~ ", paste(colnames(X),collapse="+")))) %>% predict %>% as.numeric
dml_nde_tree = rpart(as.formula(paste0("df_hte$tde_eif ~ ", paste(colnames(X),collapse="+")))) %>% predict %>% as.numeric
dml_nie_tree = rpart(as.formula(paste0("df_hte$tie_eif ~ ", paste(colnames(X),collapse="+")))) %>% predict %>% as.numeric

dml_ate_unit_rmse <- sqrt(mean((fit_ate - hnde - true_unit_nie)^2, na.rm = TRUE))
dml_ate_unit_corr <- suppressWarnings(stats::cor(fit_ate, hnde + true_unit_nie, use = "complete.obs"))
dml_nde_unit_rmse <- sqrt(mean((fit_nde - hnde)^2, na.rm = TRUE))
dml_nde_unit_corr <- suppressWarnings(stats::cor(fit_nde, hnde, use = "complete.obs"))  
dml_nie_unit_rmse <- sqrt(mean((fit_nie - true_unit_nie)^2, na.rm = TRUE))
dml_nie_unit_corr <- suppressWarnings(stats::cor(fit_nie, true_unit_nie, use = "complete.obs"))

varimp_raw <- tryCatch(variable_importance(med),
                        error = function(e) setNames(rep(NA_real_, ncol(X)), colnames(X)))
if (is.null(names(varimp_raw)) || any(is.na(names(varimp_raw)))) {
names(varimp_raw) <- colnames(X)
}
varimp <- varimp_raw[colnames(X)]
if (all(is.na(varimp))) {
vi_order <- character(0)
} else {
vi_order <- names(sort(varimp, decreasing = TRUE, na.last = NA))
}
x6_top1 <- if (length(vi_order) >= 1) identical(vi_order[1], "x6") else NA
x6_top2 <- if (length(vi_order) >= 2) any(vi_order[1:2] == "x6") else x6_top1
varimp_x6 <- unname(varimp["x6"])


# ==========================================================
# group level comparison
# ==========================================================
df_hte$ax1_bin = cut(df_hte$ax1,quantile(df_hte$ax1,0:100/100),include.lowest=TRUE) %>% as.numeric
ax1_hte = df_hte %>% 
    group_by(ax1_bin) %>%
    summarize(ax1      = mean(ax1),
              true_ate = mean(true_ate),
              true_nde = mean(true_nde),
              true_nie = mean(true_nie),
              grf_ate  = mean(est_ate),
              grf_nde  = mean(est_nde),
              grf_nie  = mean(est_nie),
              dml_ate  = mean(ate_eif,na.rm=TRUE),
              dml_nde  = mean(tde_eif,na.rm=TRUE),
              dml_nie  = mean(tie_eif,na.rm=TRUE),
              )

grfg_ate_unit_rmse <- sqrt(mean((ax1_hte$grf_ate - ax1_hte$true_ate)^2, na.rm = TRUE))
grfg_ate_unit_corr <- suppressWarnings(stats::cor(ax1_hte$grf_ate, ax1_hte$true_ate, use = "complete.obs"))
grfg_nde_unit_rmse <- sqrt(mean((ax1_hte$grf_nde - ax1_hte$true_nde)^2, na.rm = TRUE))
grfg_nde_unit_corr <- suppressWarnings(stats::cor(ax1_hte$grf_nde, ax1_hte$true_nde, use = "complete.obs"))
grfg_nie_unit_rmse <- sqrt(mean((ax1_hte$grf_nie - ax1_hte$true_nie)^2, na.rm = TRUE))
grfg_nie_unit_corr <- suppressWarnings(stats::cor(ax1_hte$grf_nie, ax1_hte$true_nie, use = "complete.obs"))

dmlg_ate_unit_rmse <- sqrt(mean((ax1_hte$dml_ate - ax1_hte$true_ate)^2, na.rm = TRUE))
dmlg_ate_unit_corr <- suppressWarnings(stats::cor(ax1_hte$dml_ate, ax1_hte$true_ate, use = "complete.obs"))
dmlg_nde_unit_rmse <- sqrt(mean((ax1_hte$dml_nde - ax1_hte$true_nde)^2, na.rm = TRUE))
dmlg_nde_unit_corr <- suppressWarnings(stats::cor(ax1_hte$dml_nde, ax1_hte$true_nde, use = "complete.obs"))
dmlg_nie_unit_rmse <- sqrt(mean((ax1_hte$dml_nie - ax1_hte$true_nie)^2, na.rm = TRUE))
dmlg_nie_unit_corr <- suppressWarnings(stats::cor(ax1_hte$dml_nie, ax1_hte$true_nie, use = "complete.obs"))


# =================== write files ===================
# The common replicate is 100
# The common sample sizes are 500, 1000, 5000, 10000
# For forest, it may also be useful to show the min.node.size change
# For each sample size, run replicate numbers; then loop the replicates across the sample sizes values
rep_results <- tibble(
    rep = rep,
    nde_hat = nde_hat,
    nde_se = nde_se,
    nde_true = true_nde,
    nie_hat = nie_hat,
    nie_se = nie_se,
    nie_true = true_nie,
    ate_hat = ate_hat,
    ate_se = ate_se,
    ate_true = true_ate,    
    ate_unit_rmse = ate_unit_rmse,
    ate_unit_corr = ate_unit_corr,
    nde_unit_rmse = nde_unit_rmse,
    nde_unit_corr = nde_unit_corr,
    nie_unit_rmse = nie_unit_rmse,
    nie_unit_corr = nie_unit_corr,
    varimp_x6 = varimp_x6,
    x6_top1 = x6_top1,
    x6_top2 = x6_top2,
    grf_ate  = mean(df_hte$est_ate,na.rm=TRUE),
    grf_nde  = mean(df_hte$est_nde,na.rm=TRUE),
    grf_nie  = mean(df_hte$est_nie,na.rm=TRUE),
    dml_ate  = mean(main_df$ate_eif,na.rm=TRUE),
    dml_nde  = mean(main_df$tde_eif,na.rm=TRUE),
    dml_nie  = mean(main_df$tie_eif,na.rm=TRUE),
    dml_ate_se = overall$se[7],
    dml_nde_se = overall$se[5],
    dml_nie_se = overall$se[6],
    dml_ate_unit_rmse = dml_ate_unit_rmse,
    dml_ate_unit_corr = dml_ate_unit_corr,
    dml_nde_unit_rmse = dml_nde_unit_rmse,
    dml_nde_unit_corr = dml_nde_unit_corr,
    dml_nie_unit_rmse = dml_nie_unit_rmse,
    dml_nie_unit_corr = dml_nie_unit_corr,
    # group level
    # grf
    grfg_ate_unit_rmse = grfg_ate_unit_rmse,
    grfg_ate_unit_corr = grfg_ate_unit_corr,
    grfg_nde_unit_rmse = grfg_nde_unit_rmse,
    grfg_nde_unit_corr = grfg_nde_unit_corr,
    grfg_nie_unit_rmse = grfg_nie_unit_rmse,
    grfg_nie_unit_corr = grfg_nie_unit_corr,
    # dml
    dmlg_ate_unit_rmse = dmlg_ate_unit_rmse,
    dmlg_ate_unit_corr = dmlg_ate_unit_corr,
    dmlg_nde_unit_rmse = dmlg_nde_unit_rmse,
    dmlg_nde_unit_corr = dmlg_nde_unit_corr,
    dmlg_nie_unit_rmse = dmlg_nie_unit_rmse,
    dmlg_nie_unit_corr = dmlg_nie_unit_corr,
  )
print(as.data.frame(rep_results))
file_path = sprintf("workingdata/simulation_case1/simulation_size%s_rep%s.rds",sample_size,rep)
print(paste("Saved to", file_path))
write_rds(rep_results,file_path)

Sys.time()
