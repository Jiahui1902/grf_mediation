/*-------------------------------------------------------------------------------
  This file is part of generalized random forest (grf).

  grf is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grf is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grf. If not, see <http://www.gnu.org/licenses/>.
 #-------------------------------------------------------------------------------*/

#include "commons/utility.h"
#include "relabeling/MedCausalRelabelingStrategy.h"

namespace grf {

MedCausalRelabelingStrategy::MedCausalRelabelingStrategy(size_t response_length,
                                                             const std::vector<double>& gradient_weights) {
  this->response_length = response_length;
  if (gradient_weights.empty()) {
    this->gradient_weights = std::vector<double> (response_length, 1.0);
  } else if (gradient_weights.size() != response_length) {
    throw std::runtime_error("Optional gradient weights vector must be same length as response_length.");
  } else {
    this->gradient_weights = gradient_weights;
  }
}

bool MedCausalRelabelingStrategy::relabel(
    const std::vector<size_t>& samples,
    const Data& data,
    Eigen::ArrayXXd& responses_by_sample) const {

  // Prepare the relevant averages.
  size_t num_samples = samples.size();
  size_t num_treatments = data.get_num_treatments();
  size_t num_outcomes = data.get_num_outcomes();
  if (num_samples <= num_treatments) {
    return true;
  }

  Eigen::MatrixXd Y_centered = Eigen::MatrixXd(num_samples, num_outcomes);
  Eigen::MatrixXd W_centered = Eigen::MatrixXd(num_samples, num_treatments);
  // M_centered and Mxa_centered are defined below
  Eigen::VectorXd weights = Eigen::VectorXd(num_samples);
  
  // because mediator is depending on treatment and thus it is of the same size with treatment  
  
  /***
   * to do mediation analysis, I will follow Tchetgen Tchetgen and Shpitser (2012). They derived the EIF for NDE and NIE on page 7. 
   * On page 10, Section 1.1 Trily robust estimation, they derived the moment condition for NDE and NIE. I will use these in 
   * training the forest. The estimator is a tripply robust estimator for the joint effect minus the doubly robust estimator for ATE.
   * 
  */
  
  
  Eigen::MatrixXd Y = Eigen::MatrixXd(num_samples, num_outcomes); // Y - Y.hat
  //  six residuals
  // estimate beta_a
  Eigen::MatrixXd Yxm = Eigen::MatrixXd(num_samples, 1);  // Y ~ X + M + C
  Eigen::MatrixXd Wxm = Eigen::MatrixXd(num_samples, 1);  // W ~ X + M + C
  // estimate beta_m
  Eigen::MatrixXd Yxa = Eigen::MatrixXd(num_samples, 1); // Y ~ X + A + C
  Eigen::MatrixXd Mxa = Eigen::MatrixXd(num_samples, 1); // M ~ X + A + C
  // estimate theta_a  
  Eigen::MatrixXd M = Eigen::MatrixXd(num_samples, 1); // M ~ X
  Eigen::MatrixXd W = Eigen::MatrixXd(num_samples, num_treatments); // W ~ X

  // calculate means to center the variables (local centering)
  Eigen::VectorXd Y_mean = Eigen::VectorXd::Zero(num_outcomes);
  // beta_a
  double yxm_mean = 0;
  double wxm_mean = 0;
  // beta_m
  double yxa_mean = 0;
  double mxa_mean = 0;
  // theta_a
  double m_mean = 0;
  Eigen::VectorXd W_mean = Eigen::VectorXd::Zero(num_treatments);    

  double sum_weight = 0;
  
  Eigen::VectorXd O = Eigen::VectorXd::Ones(num_treatments); // all Ones, change signs for treatment and controls
  // Eigen::MatrixXd control = Eigen::MatrixXd(num_samples, num_treatments); // [constant]
    
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[i];
    Eigen::VectorXd outcome = data.get_outcomes(sample); // Y - Y.hat
    Eigen::VectorXd treatment = data.get_treatments(sample); // W - W.hat
    double mediator = data.get_mediator(sample); // M - M.hat
    double yxm = data.get_Yresxm(sample); // residual of Y ~ X + M
    double yxa = data.get_Yresxa(sample); // residual of Y ~ X + A
    double wxm = data.get_Wresxm(sample); // residual of A ~ X + M
    double mxa = data.get_Mresxa(sample); // residual of M ~ X + A
    double weight = data.get_weight(sample); 
    
    Y_centered.row(i) = outcome; // residual of Y ~ X
    Y.row(i) = outcome; // residual of Y ~ X
    W_centered.row(i) = treatment; // residual of A ~ X
    W.row(i) = treatment; // residual of A ~ X
    
    weights(i) = weight;
    Y_mean += weight * outcome;         
    // beta_a
    yxm_mean += weight * yxm;
    wxm_mean += weight * wxm;
    // beta_m
    yxa_mean += weight * yxa;
    mxa_mean += weight * mxa;
    // theta_a
    m_mean += weight * mediator;
    W_mean += weight * treatment;
    // sum of weight
    sum_weight += weight;
    // Wxm.row(i) << treatment/wxm;
  }

  Y_mean /= sum_weight; // W_mean has been defined above
  yxm_mean /= sum_weight;
  wxm_mean /= sum_weight;
  yxa_mean /= sum_weight;
  mxa_mean /= sum_weight;
  m_mean /= sum_weight;
  W_mean /= sum_weight;
  
  Y_centered.rowwise() -= Y_mean.transpose();
  W_centered.rowwise() -= W_mean.transpose();
  
  // Y centered has been defined
  Eigen::MatrixXd Yxm_centered = Eigen::MatrixXd(num_samples, 1);
  Eigen::MatrixXd Wxm_centered = Eigen::MatrixXd(num_samples, 1);
  Eigen::MatrixXd Yxa_centered = Eigen::MatrixXd(num_samples, 1);
  Eigen::MatrixXd Mxa_centered = Eigen::MatrixXd(num_samples, 1);
  Eigen::MatrixXd M_centered = Eigen::MatrixXd(num_samples, 1);
  // W centered has been defined  
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[i];    
    double mediator = data.get_mediator(sample); // M - M.hat
    double yxm = data.get_Yresxm(sample); // residual of Y ~ X + M
    double yxa = data.get_Yresxa(sample); // residual of Y ~ X + A
    double wxm = data.get_Wresxm(sample); // residual of A ~ X + M
    double mxa = data.get_Mresxa(sample); // residual of M ~ X + A
    double weight = data.get_weight(sample); 
    Yxm_centered.row(i) << yxm - yxm_mean;
    Wxm_centered.row(i) << wxm - wxm_mean;
    Yxa_centered.row(i) << yxa - yxa_mean;    
    Mxa_centered.row(i) << mxa - mxa_mean;
    M_centered.row(i) << mediator - m_mean;
    // W_centered has been defined
  }
    
  if (std::abs(sum_weight) <= 1e-16) {
    return true;
  }
  
  Eigen::MatrixXd WW_bar = W_centered.transpose() * weights.asDiagonal() * W_centered; // [num_treatments X num_treatments]
  // Calculate the treatment effect.
  // This condition number check works fine in practice - there may be more robust ways.
  if (equal_doubles(WW_bar.determinant(), 0.0, 1.0e-10)) {
    return true;
  }
  // Y ~ A (total treatment effect)
  Eigen::MatrixXd A_p_inv = WW_bar.inverse();
  Eigen::MatrixXd beta_total = A_p_inv * W_centered.transpose() * weights.asDiagonal() * Y_centered; // [num_treatments X num_outcomes]

  // beta_a: NDE coefficient of A on Y
  Eigen::MatrixXd WWxm_bar = Wxm_centered.transpose() * weights.asDiagonal() * Wxm_centered; // [num_treatments X num_treatments]
  if (equal_doubles(WWxm_bar.determinant(), 0.0, 1.0e-10)) {
    return true;
  }
  Eigen::MatrixXd betaYA = WWxm_bar.inverse() * Wxm_centered.transpose() * weights.asDiagonal() * Yxm_centered; 

  // beta_m: coefficient of M on Y
  Eigen::MatrixXd MMxa_bar = Mxa_centered.transpose() * weights.asDiagonal() * Mxa_centered; // [num_treatments X num_treatments]
  if (equal_doubles(MMxa_bar.determinant(), 0.0, 1.0e-10)) {
    return true;
  }
  Eigen::MatrixXd betaYM = MMxa_bar.inverse() * Mxa_centered.transpose() * weights.asDiagonal() * Yxa_centered; 

  // theta_a: coefficient of A on M
  Eigen::MatrixXd MM_bar = M_centered.transpose() * weights.asDiagonal() * M_centered; // [num_treatments X num_treatments]
  if (equal_doubles(MM_bar.determinant(), 0.0, 1.0e-10)) {
    return true;
  }    
  Eigen::MatrixXd betaMA = A_p_inv * W_centered.transpose() * weights.asDiagonal() * M_centered; 
  
  // double betaNIE = betaMA(0)*betaYM(0);
  // double betaNDE = betaYA(0);
  // double betaNDE = beta_total(0)-betaMA(0)*betaYM(0);
  // Eigen::MatrixXd atew = W.transpose() * weights.asDiagonal() * W; 
  // if (equal_doubles(atew.determinant(), 0.0, 1.0e-10)) {
  //   return true;
  // }   
  // Eigen::MatrixXd ateadjust = atew.inverse() * W.transpose() * weights.asDiagonal() * (Y_centered - beta_total(0)*W_centered);
  // double betaNDE = ateadjust(0) + beta_total(0)-betaMA(0)*betaYM(0);
  double betaNDE = beta_total(0)-betaMA(0)*betaYM(0);
  // double betaNDE = betaYA(0);
  // residual and weight  
  Eigen::MatrixXd residual = Y_centered - W_centered * betaNDE - M_centered * betaYM(0); // the residual term should be Y - betaNDE*W - betaYM*M
  Eigen::MatrixXd residual_ate = (Y_centered - W_centered * beta_total)*(W_centered * WW_bar.inverse().transpose()); 
  // Eigen::MatrixXd rho_weight_nde = W_centered * WW_bar.inverse().transpose(); 
  // NDE
  // (A - Axm) / (Axm*(1 - pi)) = (A-Axm) / (pi * (1-pi)) * (pi/Axm)
  Eigen::MatrixXd rho_weight_nde = Wxm_centered * WW_bar.inverse().transpose(); 
  // NIE
  Eigen::MatrixXd rho_weight_nie = W_centered * WW_bar.inverse().transpose(); 
  
  

  Eigen::MatrixXd partestimator = Eigen::MatrixXd(num_samples, num_outcomes);
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[i];
    double weight = data.get_weight(sample);
    double mediator = data.get_mediator(sample);
    double effect = data.get_effect(sample);
    Eigen::VectorXd outcome = data.get_outcomes(sample);
    Eigen::VectorXd treatment = data.get_treatments(sample);  
    double pax = data.get_Pax(sample);
    double paxm = data.get_Paxm(sample);
    
    // if (equal_doubles(wxm, 0.0, 1.0e-10)) {
    // parse the ratio of Pr(A | X) / Pr(A | X, M) as pax/paxm
    partestimator.row(i) = (1 - effect )*(rho_weight_nde.row(i)*residual.row(i)*pax/paxm) + 
                  // option 1 and option 2 are equivalent
                  // option 1: direct from nie eif
                  effect*(rho_weight_nie.row(i)*(residual_ate.row(i)-residual.row(i)) +
                          (1-pax/paxm)*rho_weight_nie.row(i)*residual.row(i) +
                          (1/(1-pax))*(1-pax/paxm)*residual.row(i));  
                  // option 2: indirectly from ate_eif - nde_eif
                  // effect*(rho_weight_nie.row(i)*residual_ate.row(i)-rho_weight_nde.row(i)*residual.row(i)*pax/paxm); 
    // }
    // partestimator.row(i) = (1 - effect )*(rho_weight_nde.row(i)*residual.row(i)) + 
    //               effect*(residual_ate.row(i)-rho_weight_nde.row(i)*residual.row(i));                    
    // partestimator.row(i) = residual_ate.row(i);                  
  }

    // std::cout << "============" << std::endl;
    // std::cout << "ateadjust(0) is " << ateadjust(0) << std::endl;
    // std::cout << "pr is " << PrAM << std::endl;
    // std::cout << "residual is" << residual*10000 << std::endl;
    // std::cout << ")))))))))))))" << std::endl;
    // std::cout << "rho_weight_nde is" << rho_weight_nde << std::endl;
    // std::cout << "::::::::::::::" << std::endl;
    // std::cout << "partestimator is " << partestimator << std::endl;
    // std::cout << "ate residual is " << residual_ate << std::endl;
    // std::cout << "++++++++++++" << std::endl;


  // Create the new outcomes, eq (20) in https://arxiv.org/pdf/1610.01271.pdf
  // `responses_by_sample(sample_i, )` is a `num_treatments*num_outcomes`-sized vector.
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[i];
    size_t j = 0;
    for (size_t outcome = 0; outcome < num_outcomes; outcome++) {
      for (size_t treatment = 0; treatment < num_treatments; treatment++) {
        // original (jocobian matrix)
        // responses_by_sample(sample, j) = rho_weight(i, treatment) * residual(i, outcome) * gradient_weights[j];
        
        // for NDE and NIE
        responses_by_sample(sample, j) = partestimator(i, treatment)*gradient_weights[j];
        j++;
      }
    }
  }
  return false;
}


size_t MedCausalRelabelingStrategy::get_response_length() const {
  return response_length;
}

} // namespace grf
