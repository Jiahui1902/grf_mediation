/*-------------------------------------------------------------------------------
  This file is part of generalized random forest (grf).

  grf is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grf is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grf. If not, see <http://www.gnu.org/licenses/>.
 #-------------------------------------------------------------------------------*/
/**
 * This splitting rule is a multivariate extension of {@link InstrumentalSplittingRule}.
 * The contraints are
 * (1) treament size and control size
 * Define A_ik = W_ik < \bar{W}_k,
 * where k = 1,...,K (number of treatments) and \bar(W)_k is the average of the k'th
 * treatment in the parent.
 * Requirement: for each k, each child node must contain at least min_node_size
 * observations with A_ik = 1, and A_ik = 0.
 *
 * (2) child node size and parent node size
 * Define size(parent_k) = \sum_i{i in node} (W_ik - \bar{W}_k)^2.
 * Requirement: for each k, the size of each child must be greater or equal to
 * size(parent_k) * alpha, where alpha: (0, 0.25) is a tuning parameter.
 *
 */

#include <algorithm>
#include <iostream>

#include "MedCausalSplittingRule.h"

namespace grf {

MedCausalSplittingRule::MedCausalSplittingRule(size_t max_num_unique_values,
                                                   uint min_node_size,
                                                   double alpha,
                                                   double imbalance_penalty,
                                                   size_t response_length,
                                                   size_t num_treatments):
    min_node_size(min_node_size),
    alpha(alpha),
    imbalance_penalty(imbalance_penalty),
    response_length(response_length),
    num_treatments(num_treatments) {
  this->counter = new size_t[max_num_unique_values];
  this->weight_sums = new double[max_num_unique_values];
  this->sums = Eigen::ArrayXXd(max_num_unique_values, response_length);
  this->num_small_w = Eigen::ArrayXXi(max_num_unique_values, num_treatments);
  this->sums_w = Eigen::ArrayXXd(max_num_unique_values, num_treatments);
  this->sums_w_squared = Eigen::ArrayXXd(max_num_unique_values, num_treatments);
  this->num_small_m = new size_t[max_num_unique_values];
  this->sums_m = new double[max_num_unique_values];
  this->sums_m_squared = new double[max_num_unique_values];
}

MedCausalSplittingRule::~MedCausalSplittingRule() {
  if (counter != nullptr) {
    delete[] counter;
  }
  if (weight_sums != nullptr) {
    delete[] weight_sums;
  }
}

bool MedCausalSplittingRule::find_best_split(const Data& data,
                                               size_t node,
                                               const std::vector<size_t>& possible_split_vars,
                                               const Eigen::ArrayXXd& responses_by_sample,
                                               const std::vector<std::vector<size_t>>& samples,
                                               std::vector<size_t>& split_vars,
                                               std::vector<double>& split_values,
                                               std::vector<bool>& send_missing_left) {
  size_t num_samples = samples[node].size(); // a parent node's size (total observation number)
  // Precompute the sum of outcomes in this node.
  double weight_sum_node = 0.0;
  
  Eigen::ArrayXd sum_node = Eigen::ArrayXd::Zero(response_length); // sum of eif based response in the parent node
  Eigen::ArrayXd sum_node_w = Eigen::ArrayXd::Zero(num_treatments); // N(A=1)
  Eigen::ArrayXd sum_node_w_squared = Eigen::ArrayXd::Zero(num_treatments); // N(A=1)^2
  
  // Parallel process for mediator m (ideally), but the type is double 
  double sum_node_m = 0.0; // sum of mediator
  double sum_node_m_squared = 0.0; // square of sum mediator
  
  // control for estimating NDE or NIE
  double est_effect = 0;
  
  // Allocate W-array and re-use to avoid expensive copy-inducing calls to `data.get_treatments`
  Eigen::ArrayXXd treatments = Eigen::ArrayXXd(num_samples, num_treatments);
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[node][i];
    double sample_weight = data.get_weight(sample);
    double sample_mediator = data.get_mediator(sample);
    double effect = data.get_effect(sample);
  
    weight_sum_node += sample_weight; // node size N ; node means parent node
    sum_node += sample_weight * responses_by_sample.row(sample); // eif based response
    treatments.row(i) = data.get_treatments(sample); 
    
    sum_node_w += sample_weight * treatments.row(i); // N(A=1)
    sum_node_w_squared += sample_weight * treatments.row(i).square(); //N(A=1)^2
    
    sum_node_m += sample_weight * sample_mediator; // N(M=1)
    sum_node_m_squared += sample_weight * sample_mediator * sample_mediator; //N(M=1)^2
    
    // effect: NDE or NIE
    est_effect = effect;
      
  }
  // this is a modified 'information content' 
  // The new size measure is given by `\sum_{i in node} (W_i - \bar{W})^2`.
  Eigen::ArrayXd size_node = sum_node_w_squared - sum_node_w.square() / weight_sum_node;
  Eigen::ArrayXd min_child_size = size_node * alpha; // total variance of treatment in a parent node X alpha
 
  // information content for mediator
  double size_node_m = (sum_node_m_squared - sum_node_m*sum_node_m / (weight_sum_node));// / sum_node_w;
  double min_child_size_m = size_node_m * alpha; // total variance X alpha
  // std::cout << "min_child_size is " << min_child_size << std::endl;
  // std::cout << "min_child_size_m is " << min_child_size_m << std::endl;
  // for child node
  Eigen::ArrayXd mean_w_node = sum_node_w / weight_sum_node;
  Eigen::ArrayXi num_node_small_w = Eigen::ArrayXi::Zero(num_treatments);
  
  double mean_m_node = sum_node_m / weight_sum_node;
  size_t num_node_small_m = 0;
  
  for (size_t i = 0; i < num_samples; i++) {
    size_t sample = samples[node][i];
    double mediator = data.get_mediator(sample);
    double effect = data.get_effect(sample);
    double sample_weight = data.get_weight(sample);

    // treatment or control
    num_node_small_w += (treatments.row(i).transpose() < mean_w_node).cast<int>(); // cast<int>() is converting boolean to int, count the number of control units
    
    // mediator count of those less than mean
    // equivalent to: num_node_small_m += static_cast<int>(mediator < mean_m_node);
    if (mediator < mean_m_node) {
      num_node_small_m++;
    }
  }

  // Initialize the variables to track the best split variable.
  size_t best_var = 0;
  double best_value = 0;
  double best_decrease = 0.0;
  bool best_send_missing_left = true;

  // For all possible split variables
  for (auto& var : possible_split_vars) {
    find_best_split_value(data, node, var, num_samples, weight_sum_node, sum_node, 
                          mean_w_node, num_node_small_w, sum_node_w, sum_node_w_squared, min_child_size, treatments, 
                          mean_m_node, num_node_small_m, sum_node_m, sum_node_m_squared, min_child_size_m,                          
                          best_value,best_var, best_decrease, best_send_missing_left, responses_by_sample, samples);
  }

  // Stop if no good split found
  if (best_decrease <= 0.0) {
    return true;
  }

  // Save best values
  split_vars[node] = best_var;
  split_values[node] = best_value;
  send_missing_left[node] = best_send_missing_left;
  return false;
}

void MedCausalSplittingRule::find_best_split_value(const Data& data,
                                                     size_t node,
                                                     size_t var,
                                                     size_t num_samples,
                                                     double weight_sum_node,
                                                     const Eigen::ArrayXd& sum_node,

                                                     const Eigen::ArrayXd& mean_node_w,
                                                     const Eigen::ArrayXi& num_node_small_w,
                                                     const Eigen::ArrayXd& sum_node_w,
                                                     const Eigen::ArrayXd& sum_node_w_squared,
                                                     const Eigen::ArrayXd& min_child_size,
                                                     
                                                     const Eigen::ArrayXXd& treatments,
                                                     
                                                     const double& mean_node_m, 
                                                     const size_t& num_node_small_m, 
                                                     const double& sum_node_m, 
                                                     const double& sum_node_m_squared, 
                                                     const double& min_child_size_m, 
                                                                                                        
                                                     double& best_value,
                                                     size_t& best_var,
                                                     double& best_decrease,
                                                     bool& best_send_missing_left,
                                                     const Eigen::ArrayXXd& responses_by_sample,
                                                     const std::vector<std::vector<size_t>>& samples) {
  std::vector<double> possible_split_values;
  std::vector<size_t> sorted_samples;
  std::vector<size_t> index = data.get_all_values(possible_split_values, sorted_samples, samples[node], var);

  // Try next variable if all equal for this
  if (possible_split_values.size() < 2) {
    return;
  }
  // num_splits is at least 2
  size_t num_splits = possible_split_values.size() - 1;

  // initialize and fill the array to 0 (has been declared in the first function)
  std::fill(counter, counter + num_splits, 0);
  std::fill(weight_sums, weight_sums + num_splits, 0);
  sums.topRows(num_splits).setZero(); // response
  num_small_w.topRows(num_splits).setZero();
  sums_w.topRows(num_splits).setZero();
  sums_w_squared.topRows(num_splits).setZero();
  
  std::fill(num_small_m, num_small_m + num_splits, 0);
  std::fill(sums_m, sums_m + num_splits, 0);
  std::fill(sums_m_squared, sums_m_squared + num_splits, 0);
  

  // missings
  size_t n_missing = 0;
  double weight_sum_missing = 0;
  Eigen::ArrayXd sum_missing = Eigen::ArrayXd::Zero(response_length);
  Eigen::ArrayXd sum_w_missing = Eigen::ArrayXd::Zero(num_treatments);
  Eigen::ArrayXd sum_w_squared_missing = Eigen::ArrayXd::Zero(num_treatments);  
  
  double sum_m_missing = 0;
  double sum_m_squared_missing = 0;
  
  Eigen::ArrayXi num_small_w_missing = Eigen::ArrayXi::Zero(num_treatments);
  size_t num_small_m_missing = 0;
  size_t num_big_m_missing = 0;
  
  double est_effect = 0;
  
  size_t split_index = 0;
  for (size_t i = 0; i < num_samples - 1; i++) {
    size_t sample = sorted_samples[i];
    size_t next_sample = sorted_samples[i + 1];
    size_t sort_index = index[i];
    double sample_value = data.get(sample, var);
    double sample_weight = data.get_weight(sample);
    double sample_mediator = data.get_mediator(sample);
    double effect = data.get_effect(sample);
    est_effect = effect;
    // std::cout << "mediator mean is " <<  << std::endl;
    // std::cout << "sort_index is " << sort_index << std::endl;
    // std::cout << "sample value is " << sample_value << std::endl;
    // std::cout << "mediator is " << sample_mediator << std::endl;
    // std::cout << "mediator calculation is " << sample_weight * sample_mediator * sample_mediator << std::endl;
    // std::cout << "sum_m_squared is " << sum_m_squared_missing << std::endl;
    // std::cout << "sum_w_squared is " << sum_w_squared_missing << std::endl;
    if (std::isnan(sample_value)) {
      weight_sum_missing += sample_weight;
      sum_missing += sample_weight * responses_by_sample.row(sample); // sum rho
      ++n_missing;

      sum_w_missing += sample_weight * treatments.row(sort_index);
      sum_w_squared_missing += sample_weight * treatments.row(sort_index).square();
      
      sum_m_missing += sample_weight * sample_mediator;
      sum_m_squared_missing += sample_weight * sample_mediator * sample_mediator;
      // treatment, control count
      num_small_w_missing += (treatments.row(sort_index).transpose() < mean_node_w).cast<int>();
      // mediator count            
      if ( (sample_mediator < mean_node_m) ){
        ++num_small_m_missing;
      }                
    } else {
      weight_sums[split_index] += sample_weight;
      sums.row(split_index) += sample_weight * responses_by_sample.row(sample); //sums means the eif
      ++counter[split_index]; //split count

      sums_w.row(split_index) += sample_weight * treatments.row(sort_index);
      sums_w_squared.row(split_index) += sample_weight * treatments.row(sort_index).square();
      
      sums_m[split_index] += sample_weight * sample_mediator;
      sums_m_squared[split_index] += sample_weight * sample_mediator * sample_mediator;
      // std::cout << "sums_m_squared[split_index] is " << sums_m_squared[split_index] << std::endl;
      
      num_small_w.row(split_index) += (treatments.row(sort_index).transpose() < mean_node_w).cast<int>();
      if ( sample_mediator < mean_node_m ){
        ++num_small_m[split_index];
      }            
    }
    // std::cout << "sum_m after the loop is " << sums_m_squared << std::endl;
    // std::cout << "sum_w after the loop is " << sums_w_squared << std::endl;
    double next_sample_value = data.get(next_sample, var);
    // if the next sample value is different, including the transition (..., NaN, Xij, ...)
    // then move on to the next bucket (all logical operators with NaN evaluates to false by default)
    if (sample_value != next_sample_value && !std::isnan(next_sample_value)) {
      ++split_index;
    }
  } // w is a matrix with shape of split_index X num_treatments
  
  
  size_t n_left = n_missing; //total number
  double weight_sum_left = weight_sum_missing;
  Eigen::Ref<Eigen::ArrayXd> sum_left = sum_missing;
  Eigen::Ref<Eigen::ArrayXd> sum_left_w = sum_w_missing;
  Eigen::Ref<Eigen::ArrayXd> sum_left_w_squared = sum_w_squared_missing;
  Eigen::Ref<Eigen::ArrayXi> num_left_small_w = num_small_w_missing;
  
  double sum_left_m = sum_m_missing;
  double sum_left_m_squared = sum_m_squared_missing;
  size_t num_left_small_m = num_small_m_missing;
  
  // Compute decrease of impurity for each possible split
  for (bool send_left : {true, false}) {
    if (!send_left) {
      // A normal split with no NaNs, so we can stop early.
      if (n_missing == 0) {
        break; // break means stopping earlier
      }
      // It is not necessary to adjust n_right or sum_right as the the missing
      // part is included in the total sum.
      n_left = 0;
      weight_sum_left = 0;
      sum_left.setZero();
      sum_left_w.setZero();
      sum_left_w_squared.setZero();        
      
      num_left_small_w.setZero();
      num_left_small_m = 0;      
    }

    for (size_t i = 0; i < num_splits; ++i) {
      // not necessary to evaluate sending right when splitting on NaN.
      if (i == 0 && !send_left) {
        continue;
      }

      n_left += counter[i]; // count of A = 1
      weight_sum_left += weight_sums[i];      
      num_left_small_w += num_small_w.row(i); // count of A = 0 
      sum_left += sums.row(i);
      sum_left_w += sums_w.row(i);
      sum_left_w_squared += sums_w_squared.row(i);
      
      // mediator:
      num_left_small_m += num_small_m[i];      
      sum_left_m += sums_m[i];
      sum_left_m_squared += sums_m_squared[i];

      // mediator count --------------------------------
      // count mediator first. Otherwise, there may be a node with 1 treatment 3 control when the split stops and at that point, the mediators are all zeros
      if (min_node_size < 5){
        min_node_size = 5;
      }

      if (num_samples < 5){
        break;
      }

      if ((num_left_small_m < min_node_size) || (n_left - num_left_small_m < min_node_size)) {
        continue;
      }
      size_t n_right = num_samples - n_left;
      if (((num_node_small_m - num_left_small_m) < min_node_size) ||
          (n_right - num_node_small_m + num_left_small_m < min_node_size)) {
        break;
      }
      
      // #1 number/count --------------------------------
      // --- Y00 || Y10 || Y11 on left ----
      if ((num_left_small_w < min_node_size).any() || (n_left - num_left_small_w < min_node_size).any()) {
        continue;
      }
      
      // for count
      // Stop if the right child does not contain enough w values below
      // and above the parent's mean.
      // size_t n_right = num_samples - n_left;
      // // We have:
      // // Eigen::ArrayXi num_right_small_w = num_node_small_w - num_left_small_w
      // // Eigen::ArrayXi num_right_large_w = n_right - num_right_small_w
      // // Same as: if ((num_right_small_w < min_node_size).any() || (num_right_large_w < min_node_size).any())
      
      if ((num_node_small_w - num_left_small_w < min_node_size).any() ||
          (n_right - num_node_small_w + num_left_small_w < min_node_size).any()) {
        break;
      }
      // std::cout << "num_left_small_m is " << num_left_small_m << std::endl;
      


      // for values/variance treatment
      if ((sum_left_w_squared - sum_left_w.square() / weight_sum_left < min_child_size).any() ||
          (imbalance_penalty > 0.0 && (sum_left_w_squared - sum_left_w.square() / weight_sum_left == 0).all())) {
        continue;
      }

      // Calculate relevant quantities for the right child.
      double weight_sum_right = weight_sum_node - weight_sum_left;
      // We have:
      // Eigen::ArrayXd sum_right_w_squared = sum_node_w_squared - sum_left_w_squared;
      // Eigen::ArrayXd sum_right_w = sum_node_w - sum_left_w;
      // Eigen::ArrayXd size_right = sum_right_w_squared - sum_right_w.square() / weight_sum_right;
      // Skip this split if the right child's variance is too small.
      // Same as: if ((size_right < min_child_size).any() || (imbalance_penalty > 0.0 && (size_right == 0).all()))
      if ((sum_node_w_squared - sum_left_w_squared - (sum_node_w - sum_left_w).square() / weight_sum_right < min_child_size).any() ||
          (imbalance_penalty > 0.0 && (sum_node_w_squared - sum_left_w_squared - (sum_node_w - sum_left_w).square() / weight_sum_right == 0).all())) {
        continue;
      }
      
    // std::cout << "sum_left_m part is " << sum_left_m_squared << std::endl;
    // std::cout << "sum_left_m_squared is " << sum_left_m_squared - sum_left_m*sum_left_m / weight_sum_left << std::endl;
    // relevant node size mediator: for values/variance mediator
      // std::cout << "min_child_size(0) is " << min_child_size(0) << std::endl;
      // std::cout << "min_child_size_m is " << min_child_size_m << std::endl;
      if ((sum_left_m_squared - sum_left_m*sum_left_m / weight_sum_left < min_child_size_m) ||
          (imbalance_penalty > 0.0 && (sum_left_m_squared - sum_left_m*sum_left_m / weight_sum_left == 0))) {
        continue;
      }
      
      if ((sum_node_m_squared - sum_left_m_squared - (sum_node_m - sum_left_m)*(sum_node_m - sum_left_m) / weight_sum_right < min_child_size_m) ||
          (imbalance_penalty > 0.0 && (sum_node_m_squared - sum_left_m_squared - (sum_node_m - sum_left_m)*(sum_node_m - sum_left_m) / weight_sum_right == 0) )) {
        continue;
      }
      
      
      // Calculate the decrease in impurity.
      // We have `Eigen::ArrayXd sum_right = sum_node - sum_left` but write down the expression
      // in-place below to avoid unnecessary temporaries.
      double decrease = sum_left.square().sum() / weight_sum_left +
                        (sum_node - sum_left).square().sum() / weight_sum_right;

      // Penalize splits that are too close to the edges of the data. to avoid child nodes have too different size
      double penalty = imbalance_penalty * (1.0 / n_left + 1.0 / n_right);
      // double penalty = .01 * (1.0 / n_left + 1.0 / n_right);
      decrease -= penalty;

      // If better than before, use this
      if (decrease > best_decrease) {
        best_value = possible_split_values[i];
        best_var = var;
        best_decrease = decrease;
        best_send_missing_left = send_left;
      }
    }
  }
  
}

} // namespace grf
