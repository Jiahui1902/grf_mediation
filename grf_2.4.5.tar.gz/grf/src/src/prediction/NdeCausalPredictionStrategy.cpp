/*-------------------------------------------------------------------------------
  This file is part of generalized random forest (grf).

  grf is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  grf is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with grf. If not, see <http://www.gnu.org/licenses/>.
 #-------------------------------------------------------------------------------*/

#include <cmath>
#include <vector>
#include <iostream>

#include "commons/Data.h"
#include "commons/utility.h"
#include "prediction/NdeCausalPredictionStrategy.h"


namespace grf {

NdeCausalPredictionStrategy::NdeCausalPredictionStrategy(size_t num_treatments,
                                                             size_t num_outcomes) {
  this->num_treatments = num_treatments;
  this->num_outcomes = num_outcomes;
// {sum_weight, sum_Y, sum_W, sum_YW, sum_WW, sum_Y1M, sum_Y0M, sum_Y10, sum_M11, sum_M01, sum_weight0, sum_weight1}
// {sum_weight, sum_Y, sum_W, sum_YW, sum_WW, sum_Y1M, sum_Y0M, sum_Y10, sum_Y10ct,eif_var, effect}
//   this->num_types = num_treatments * (num_treatments + num_outcomes + 1) + num_outcomes + 1;
  this->num_types = num_treatments * (num_treatments + num_outcomes + 1) + num_outcomes + 1 + 3 * (num_outcomes) + 4;
  
  this->weight_index = 0; // the first value in the value saved
  this->Y_index = 1;
  this->W_index = this->Y_index + num_outcomes;
  this->YW_index = this->W_index + num_treatments;  
  this->WW_index = this->YW_index + num_treatments * num_outcomes;  
  
  this->Y1M_index = this->WW_index + 1;
  this->Y0M_index = this->Y1M_index + num_outcomes;
  this->Y10_index = this->Y0M_index + num_outcomes;
  this->Y10ct_index = this->Y10_index + 1;
  this->eifvar_index = this->Y10ct_index + 1;
  
  this->sum_effect_index = this->eifvar_index + 1;
  this->sum_eifcv_index = this->sum_effect_index + 1;
}

size_t NdeCausalPredictionStrategy::prediction_length() const {
    return num_treatments * num_outcomes;
}


std::vector<double> NdeCausalPredictionStrategy::predict(
  const std::vector<double>& average) const {
  // Re-construct the relevant data structures from the std::vector produced in `precompute_prediction_values`
  double weight_bar = average[weight_index];
  double effect_bar = average[sum_effect_index]; // choice: estimating for NDE or NIE
  Eigen::Map<const Eigen::VectorXd> Y10ct_bar(average.data() + Y10ct_index, num_outcomes);
  
  // Why we do not do a `...ldlt().solve(...)` instead of inverse: because dim(W) is low (intended use-case)
  // and ^-1 replicates the behavior of InstrumentalPredictionStrategy for dim(W) = 1.    
  Eigen::MatrixXd theta = (1 - effect_bar )*Y10ct_bar + effect_bar*Y10ct_bar;
  
  Eigen::Map<const Eigen::VectorXd> Y_bar(average.data() + Y_index, num_outcomes);
  Eigen::Map<const Eigen::VectorXd> W_bar(average.data() + W_index, num_treatments);
  Eigen::Map<const Eigen::MatrixXd> YW_bar(average.data() + YW_index, num_treatments, num_outcomes);
  Eigen::Map<const Eigen::MatrixXd> WW_bar(average.data() + WW_index, num_treatments, num_treatments);
  
  // Eigen::MatrixXd theta = (WW_bar * weight_bar - W_bar * W_bar.transpose()).inverse() *
  //   (YW_bar * weight_bar - W_bar * Y_bar.transpose());
  // theta = (1-effect_bar)*(theta - Y10ct_bar) + effect_bar*Y10ct_bar;
  // Eigen::MatrixXd theta = (1 - effect_bar )*(Y_bar - W_bar*beta) + effect_bar*beta;
  return std::vector<double> (theta.data(), theta.data() + prediction_length());
}

/**
 * The following calculations follow directly from {@link InstrumentalPredictionStrategy}.
 * Yi is real valued, Wi is a 1xK vector, Gi are sample weights.
 * The scoring function is:
 * psi_{mu, tau}^1(Yi, Wi, Gi) = Gi Wi (Yi - Wi tau - mu),
 * psi_{mu, tau}^2(Yi, Wi, Gi) = Gi (Yi - Wi tau - mu).
 *
 * The Hessian V(x) is:
 * V11(x) = A; V12(x) = b
 * V21(x) = b'; V22(x) = c
 * where
 * A = E[Gi Wi Wi' | Xi = x]
 * b = E[Gi Wi | Xi = x]
 * c = E[Gi | Xi = x]
 *
 * Using the matrix inverse formula in block form we get
 * rhoi = \xi' hat{V}^{-1} psi_{hat{mu}, hat{tau}}(Yi, Wi, Gi)
 *      = term1 * psi_1 - term2 * psi_2
 * where \xi selects the first K-subvector and
 * term1 = A^{-1} + 1/k A^{-1} b b' A^{-1},
 * term2 = 1/k A^{-1} b,
 * and k = c - b' A^{-1} b
 */
std::vector<double> NdeCausalPredictionStrategy::compute_variance(
    const std::vector<double>& average, // I stored the eif variance here
    const PredictionValues& leaf_values,
    size_t ci_group_size) const {
  if (num_outcomes > 1) {
    throw std::runtime_error("Pointwise variance estimates are only implemented for one outcome."); // this means that for multiple outcomes, there is no way
  }
  
  double weight_bar = average[weight_index];
  Eigen::Map<const Eigen::VectorXd> average_eif(average.data() + eifvar_index, num_outcomes);
  
  // same across forest methods 
  double num_good_groups = 0;
  Eigen::VectorXd rho_squared = Eigen::VectorXd::Zero(num_treatments);
  Eigen::VectorXd rho_grouped_squared = Eigen::VectorXd::Zero(num_treatments);

  Eigen::VectorXd group_rho = Eigen::VectorXd(num_treatments);
  Eigen::VectorXd rho = Eigen::VectorXd(num_treatments);

  // same across forest methods
  for (size_t group = 0; group < leaf_values.get_num_nodes() / ci_group_size; ++group) {
    bool good_group = true;
    for (size_t j = 0; j < ci_group_size; ++j) {
      if (leaf_values.empty(group * ci_group_size + j)) {
        good_group = false;
      }
    }
    if (!good_group) continue;

    num_good_groups++;
    group_rho.setZero();

    for (size_t j = 0; j < ci_group_size; ++j) {

      size_t i = group * ci_group_size + j;
      const std::vector<double>& leaf_value = leaf_values.get_values(i);
      
      // double leaf_weight = leaf_value[weight_index];
      Eigen::Map<const Eigen::VectorXd> leaf_eifvar(average.data() + eifvar_index, num_outcomes);
      
      rho = leaf_eifvar - average_eif; 
      rho_squared += rho.array().square().matrix();
      group_rho += rho;
    }

    group_rho /= static_cast<double>(ci_group_size);
    rho_grouped_squared += group_rho.array().square().matrix();
  }

  Eigen::VectorXd var_between = rho_grouped_squared / num_good_groups;
  Eigen::VectorXd var_total = rho_squared / (num_good_groups * ci_group_size);

  // This is the amount by which var_between is inflated due to using small groups
  Eigen::VectorXd group_noise = (var_total - var_between) / (ci_group_size - 1);

  // A simple variance correction, would be to use:
  // var_debiased = var_between - group_noise.
  // However, this may be biased in small samples; we do an elementwise objective
  // Bayes analysis of variance instead to avoid negative values.
  std::vector<double> var_debiased(num_treatments);
  for (size_t i = 0; i < num_treatments; i++) {
    var_debiased[i] = bayes_debiaser.debias(var_between[i], group_noise[i], num_good_groups);
  }
  return var_debiased;
}



size_t NdeCausalPredictionStrategy::prediction_value_length() const {
  return num_types;
}


PredictionValues NdeCausalPredictionStrategy::precompute_prediction_values(
    const std::vector<std::vector<size_t>>& leaf_samples,
    const Data& data) const {
  size_t num_leaves = leaf_samples.size(); // not divided by this value
  std::vector<std::vector<double>> values(num_leaves); // vector of vectors. outer initizlized as num_leaves. inner initialized as empty
  // outer dimension has num_leaves elements (each of which is a vector), and the inner vectors (which will hold double values) are initially empty. 

  // for each inner vector
  for (size_t i = 0; i < leaf_samples.size(); ++i) {
    size_t num_samples = leaf_samples[i].size(); // finally divided by this value, such as W_bar = sum_W / num_samples
    if (num_samples == 0) {
      continue;
    }
  // when calculating sum: they used the form (auto& sample : leaf_samples[i]) in the for loop
  
    Eigen::VectorXd sum_Y = Eigen::VectorXd::Zero(num_outcomes);
    Eigen::VectorXd sum_W = Eigen::VectorXd::Zero(num_treatments);
    Eigen::MatrixXd sum_YW = Eigen::MatrixXd::Zero(num_treatments, num_outcomes);
    Eigen::MatrixXd sum_WW = Eigen::MatrixXd::Zero(num_treatments, num_treatments);
    
    
    // keep these values temporarily
    Eigen::VectorXd sum_Y1M = Eigen::VectorXd::Zero(num_outcomes);
    Eigen::VectorXd sum_Y0M = Eigen::VectorXd::Zero(num_outcomes);
    Eigen::VectorXd sum_Y10 = Eigen::VectorXd::Zero(num_outcomes);
    
    //counterfactual    
    double sum_Y10ct = 0;    
    
    // controling
    double sum_effect = 0.0;
    double sum_eifcv = 0.0; 
    
    // get sums for calculating means
    double sum_weight = 0.0;
    
    // sumY is defined
    // beta_a
    double sum_yxm = 0.0;
    double sum_wxm = 0.0;
    // beta_m
    double sum_yxa = 0.0;
    double sum_mxa = 0.0;
    // theta_a
    double sum_m = 0.0;
    // sumW is defined
    
    for (auto& sample : leaf_samples[i]) { // for each element in the leaf_samples[i], imagine a tree has two split, within each split, iterate each element
      // want to test if samples mean the 109 different IDs: yes
      // std::cout << "leaf_samples[i] is " << sample << std::endl;
      Eigen::VectorXd outcome = data.get_outcomes(sample);
      Eigen::VectorXd treatment = data.get_treatments(sample);
      double mediator = data.get_mediator(sample); // M - M.hat
      double yxm = data.get_Yresxm(sample); // residual of Y ~ X + M
      double yxa = data.get_Yresxa(sample); // residual of Y ~ X + A
      double wxm = data.get_Wresxm(sample); // residual of A ~ X + M
      double mxa = data.get_Mresxa(sample); // residual of M ~ X + A
      double weight = data.get_weight(sample);     
      double effect = data.get_effect(sample);
      
      sum_Y += weight * outcome;
      sum_W += weight * treatment;
      sum_YW.noalias() += weight * treatment * outcome.transpose();
      sum_WW.noalias() += weight * treatment * treatment.transpose();
      
      sum_effect += effect; 
      
      sum_weight += weight;
      
      // beta_a
      sum_yxm += yxm;
      sum_wxm += wxm;
      // beta_m
      sum_yxa += yxa;
      sum_mxa += mxa;
      // theta_a
      sum_m += mediator;
    }
    
    Eigen::VectorXd Y_mean = sum_Y / sum_weight;
    Eigen::VectorXd W_mean = sum_W / sum_weight;

    // if total weight is very small, treat the leaf as empty
    if (std::abs(sum_weight) <= 1e-16) {
      continue;
    }    
    
    Eigen::VectorXd weights = Eigen::VectorXd(num_samples);
    Eigen::MatrixXd Y = Eigen::MatrixXd(num_samples, num_outcomes);
    Eigen::MatrixXd Y_centered = Eigen::MatrixXd(num_samples, num_outcomes);
    Eigen::MatrixXd W = Eigen::MatrixXd(leaf_samples[i].size(), num_treatments); 
    Eigen::MatrixXd W_centered = Eigen::MatrixXd(leaf_samples[i].size(), num_treatments); 
    Eigen::MatrixXd M = Eigen::MatrixXd(num_samples, 1); // [mediator]
    Eigen::MatrixXd M_centered = Eigen::MatrixXd(num_samples, 1); // [mediator]
    

    Eigen::MatrixXd Yxm_centered = Eigen::MatrixXd(num_samples, 1); 
    Eigen::MatrixXd Wxm_centered = Eigen::MatrixXd(num_samples, 1); 
    Eigen::MatrixXd Yxa_centered = Eigen::MatrixXd(num_samples, 1);
    Eigen::MatrixXd Mxa_centered = Eigen::MatrixXd(num_samples, 1); // [mediator]    
    
  
    // Eigen::MatrixXd Yxa = Eigen::MatrixXd(num_samples, 1); 
    // Eigen::MatrixXd Mxa = Eigen::MatrixXd(num_samples, 1); // [mediator]
        
    double yxm_mean = sum_yxm/sum_weight;  
    double wxm_mean = sum_wxm/sum_weight;  
    
    double yxa_mean = sum_yxa/sum_weight;
    double mxa_mean = sum_mxa/sum_weight;
    
    double m_mean = sum_m/sum_weight;

    for (size_t j = 0; j < num_samples; j++) {
      size_t sample = leaf_samples[i][j];
      double weight = data.get_weight(sample);
      double mediator = data.get_mediator(sample);      
      double yxm = data.get_Yresxm(sample); // residual of Y ~ X + M
      double yxa = data.get_Yresxa(sample); // residual of Y ~ X + A
      double wxm = data.get_Wresxm(sample); // residual of A ~ X + M
      double mxa = data.get_Mresxa(sample); // residual of M ~ X + A
      Eigen::VectorXd outcome = data.get_outcomes(sample);
      Eigen::VectorXd treatment = data.get_treatments(sample);

      weights(j) = weight;      
      Y_centered.row(j) << outcome - Y_mean;
      Yxm_centered.row(j) << yxm - yxm_mean;
      Wxm_centered.row(j) << wxm - wxm_mean;
      
      Mxa_centered.row(j) << mxa - mxa_mean;
      Yxa_centered.row(j) << yxa - yxa_mean;              
      M_centered.row(j) << mediator - m_mean;
      W.row(j) << treatment;
      W_centered.row(j) << treatment - W_mean;
      }
    
    // regression   
    // total treatment effect  
    Eigen::MatrixXd beta_total = (W_centered.transpose()* weights.asDiagonal() *W_centered).inverse() * W_centered.transpose() * Y_centered;
    // beta_a coefficient of A on Y
    Eigen::MatrixXd betaYA = (Wxm_centered.transpose()* weights.asDiagonal()*Wxm_centered).inverse() * Wxm_centered.transpose() * Yxm_centered;
    // beta_m
    Eigen::MatrixXd betaYM = (Mxa_centered.transpose()* weights.asDiagonal() * Mxa_centered).inverse() * Mxa_centered.transpose() * Yxa_centered;
    // theta_a    
    Eigen::MatrixXd betaMA = (W_centered.transpose()* weights.asDiagonal() * W_centered).inverse() * W_centered.transpose() * M_centered;
    // adjust value
    // Eigen::MatrixXd ateadjust = (W.transpose()* weights.asDiagonal() *W).inverse() * W.transpose() * weights.asDiagonal() * (Y_centered - beta_total(0)*W_centered);
    double sum_eifvariance = 0.0;
    // for (auto& sample : leaf_samples[i]) {
    for (size_t k = 0; k < num_samples; k++) {
      size_t sample = leaf_samples[i][k];
      double effect = data.get_effect(sample);      
      // double weight = data.get_weight(sample);
      // double mediator = data.get_mediator(sample);
      // Eigen::VectorXd outcome = data.get_outcomes(sample);
      // Eigen::VectorXd treatment = data.get_treatments(sample);
      // double aaaa = betaYA(0);
      // double aaaa = (1 - effect )*(betaYA(0)) + effect*(betaMA(0)*betaYM(0));      
      // double aaaa = (1 - effect )*(ateadjust(0) + beta_total(0)-betaMA(0)*betaYM(0)) + effect*(betaMA(0)*betaYM(0));      
      double aaaa = (1 - effect )*(beta_total(0)-betaMA(0)*betaYM(0)) + effect*(betaMA(0)*betaYM(0));      
      sum_eifvariance += aaaa; // for debiased error term in the prediction results
      sum_Y10ct += aaaa; // point estimate (also the eif value)
      sum_eifcv += betaYM(0); // for leave one out cross-validation          
      // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    }
    
        
    // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // Compute leave one tree out prediction 
    // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    std::vector<double>& value = values[i]; // store in this preallocated values, inner vector
    value.reserve(num_types);
    // store sufficient statistics in order
    // {sum_weight, sum_Y, sum_W, sum_YW, sum_WW, sum_Y1M, sum_Y0M, sum_Y10, sum_M11, sum_M01, sum_weight0, sum_weight1}
    // {sum_weight, sum_Y, sum_W, sum_YW, sum_WW, sum_Y1M, sum_Y0M, sum_Y10, sum_Y10ct, eif_var}
    value.push_back(sum_weight / num_samples);
    for (size_t j = 0; j < num_outcomes; j++) {
      value.push_back(sum_Y[j] / num_samples);
    }
    for (size_t j = 0; j < num_treatments; j++) {
      value.push_back(sum_W[j] / num_samples);
    }
    for (size_t j = 0; j < num_treatments * num_outcomes; j++) {
      value.push_back(sum_YW.data()[j] / num_samples);
    }
    for (size_t j = 0; j < num_treatments * num_treatments; j++) {
      value.push_back(sum_WW.data()[j] / num_samples);
    }

    for (size_t j = 0; j < num_treatments * num_treatments; j++) {
      value.push_back(sum_Y1M.data()[j] * sum_weight / sum_weight / num_samples);
    }
    for (size_t j = 0; j < num_treatments * num_treatments; j++) {
      value.push_back(sum_Y0M.data()[j] * sum_weight / sum_weight / num_samples);
    }
    for (size_t j = 0; j < num_treatments * num_treatments; j++) {
      value.push_back(sum_Y10.data()[j] * sum_weight / sum_weight / num_samples);
    }    
    
    value.push_back(sum_Y10ct / num_samples); // for the point estimate

    value.push_back(sum_eifvariance / num_samples); // for the variance
    value.push_back(sum_effect / num_samples); // for controlling for NDE or NIE
    value.push_back(sum_eifcv / num_samples); // loto prediction (leave one tree out)   
  }

  return PredictionValues(values, num_types);
}

std::vector<std::pair<double, double>> NdeCausalPredictionStrategy::compute_error(
    size_t sample,
    const std::vector<double>& average,
    const PredictionValues& leaf_values,
    const Data& data) const {
  
  // // std::cout << "===============" << std::endl;    
  // // std::cout << "number of nodes in the prediction is " << leaf_values.get_num_nodes() << std::endl;
  
  // ------------------------------------------
  // leave one tree out predictions
  // ------------------------------------------
  // double weight_bar = average[weight_index];
  // double effect_bar = average[sum_effect_index]; // choice: estimating for NDE or NIE
  Eigen::Map<const Eigen::VectorXd> Y10ct_bar(average.data() + Y10ct_index, num_outcomes);
  Eigen::Map<const Eigen::VectorXd> sum_eifcv_bar(average.data() + sum_eifcv_index, num_outcomes);
  Eigen::Map<const Eigen::VectorXd> eifvar_bar(average.data() + eifvar_index, num_outcomes);
  // Eigen::Map<const Eigen::VectorXd> eifvar_bar(average.data() + sum_eifcv_index, num_outcomes);
  // Eigen::Map<const Eigen::VectorXd> Y_bar(average.data() + Y_index, num_outcomes);
  // Eigen::Map<const Eigen::VectorXd> W_bar(average.data() + W_index, num_treatments);
  // Eigen::MatrixXd estimate = sum_eifcv_bar;
  
  // Eigen::VectorXd outcome = data.get_outcomes(sample);
  // Eigen::VectorXd treatment = data.get_treatments(sample);
  // double residual = outcome - (treatment - W_bar) * estimate - Y_bar;
  // double error_raw = residual * residual;
  
  // Estimates the Monte Carlo bias of the raw error via the jackknife estimate of variance.
  size_t num_trees = 0;
  for (size_t n = 0; n < leaf_values.get_num_nodes(); n++) {
    if (leaf_values.empty(n)) {
      continue;
    }
    num_trees++;
  }
  // If the treatment effect estimate is due to less than 5 trees, do not attempt to estimate error,
  // as this quantity is unstable due to non-linearities.
  
  if (num_trees <= 5) {
    return { std::make_pair<double, double>(NAN, NAN) };
  }

  // Compute 'leave one tree out' treatment effect estimates, and use them get a jackknife estimate of the excess error.
  // We do this by "decrementing" each of the the averaged (over num_trees) sufficient statistics by one component,
  // leading to the adjustment `(num_trees * "average" - "component")/(num_trees - 1)`.
  double est = 0.0;
  double est_loto = 1.0;
  // for (size_t n = 0; n < leaf_values.get_num_nodes(); n++) {
  //   if (leaf_values.empty(n)) {
  //     continue;
  //   }
  //   const std::vector<double>& leaf_value = leaf_values.get_values(n);
  //   double effect_bar = average[sum_effect_index];
  //   Eigen::Map<const Eigen::VectorXd> Y10ct_bar(average.data() + Y10ct_index, num_outcomes);
  //   Eigen::Map<const Eigen::VectorXd> sum_eifcv_bar(average.data() + sum_eifcv_index, num_outcomes);
  //   // est += (1 - effect_bar )*Y10ct_bar(0,0) + effect_bar*Y10ct_bar(0,0);
  //   est += sum_eifcv_bar(0,0);
  //   est_loto += (1 - effect_bar )*((Y10ct_bar(0,0) * num_trees - leaf_value.at(Y10ct_index))/(num_trees - 1)) + effect_bar*((Y10ct_bar(0,0) * num_trees - leaf_value.at(Y10ct_index))/(num_trees - 1));
  //   // std::cout << "est is " << est << std::endl;    
  //   // std::cout << "est loto is " << est_loto << std::endl; 
  //   // est_loto += num_trees;
  // }
  
  // average over num of trees
  // est += eifvar_bar(0,0);
  // est += Y10ct_bar(0,0);
  est += sum_eifcv_bar(0,0);
  est_loto /= num_trees;
  
  double debiased_error = est;
  double error_bias = est_loto;
  auto output = std::make_pair(debiased_error, error_bias);
  // std::cout << "+++++++++++++++++++++" << std::endl;
  // std::cout << "eifvar_bar is " << eifvar_bar(0,0) << std::endl;
  // std::cout << "sum_eif_cv is " << sum_eifcv_bar(0,0) << std::endl;
  // std::cout << "sum_Y10ct_bar is " << Y10ct_bar(0,0) << std::endl;
  // std::cout << "=====================" << std::endl;
  // std::cout << "Y10ct bar is " << Y10ct_bar(0,0) << std::endl;    
  // std::cout << "the sum eif cv is " << sum_eifcv_bar(0,0) << std::endl;    
  // std::cout << "eif var bar is " << eifvar_bar(0,0) << std::endl;    
  // std::cout << "the computed output first is " << output.first << std::endl;    
  // std::cout << "the computed output second is " << output.second << std::endl;    
  // // // std::cout << "Pair: (" << myPair.first << ", " << myPair.second << ")" << std::endl;
  // std::cout << "+++++++++++++++" << std::endl;    
  return {output};

  // return { std::make_pair<double, double>(NAN, NAN) }; // original output
}

} // namespace grf
