# load NLSY 79 data and remove 46 observations when att == 0 & comp == 1

# rm(list = ls())
# load packages ------------
library("grf")
library("tidyverse")
library("magrittr")
library("haven")
library("data.table")
select <- dplyr::select
set.seed(12345)

# load self-defined function: adding grf regression forest to superlearner------------
if(Sys.info()["user"]=="jiahuixu"){
  setwd("/Users/jiahuixu/Dropbox/_research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="xujiahui"){
  setwd("/Users/xujiahui/Dropbox/_research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="jpx5053"){
  setwd("/storage/work/jpx5053/research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}

# load NLSY 79 data ---------
# outcome: pov, povprop
# treatment: att4ycoll20
# mediator: compcoll25
nlsy79_full <- read_dta("workingdata/edurose79_socioeconomicoutcomes_20240508.dta")
nlsy79_full$id <- nlsy79_full$R0000100
nlsy79_full$att4ycoll20 = as.numeric(nlsy79_full$att4ycoll20)
nlsy79_full$compcoll25 = as.numeric(nlsy79_full$compcoll25)

## listwise delete NAs in outcome, treatment, mediator, and confounders ----
nlsy79_nona <- nlsy79_full %>%
  dplyr::select(id,att4ycoll20,compcoll25,pov,povprop,propsc_att20lin,
                male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,good) %>%
  na.omit()
### remove cases when att == 0 & comp == 1 # 34 cases
nlsy79_nona%>%select(att4ycoll20,compcoll25) %>% table

nlsy79_nona <- nlsy79_nona%>%filter(!(att4ycoll20==0&compcoll25==1))

nlsy79_nona <- left_join(nlsy79_nona,nlsy79_full)
nlsy79_nona$weight <- 1 # without adding sampling weight
nlsy79_nona %>% dim # 3456


X <- nlsy79_nona %>%
  dplyr::select(propsc_att20lin,
                male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,good) %>%
  as.data.frame
Y1 <- nlsy79_nona$povprop %>% as.vector()
Y2 <- nlsy79_nona$pov %>% as.vector()
W <- nlsy79_nona$att4ycoll20 %>% as.vector()
W_comp <- nlsy79_nona$compcoll25 %>% as.vector()

