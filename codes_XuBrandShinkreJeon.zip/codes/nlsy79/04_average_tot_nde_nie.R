# This script is to generate:
# 1. variable balance check with grf
# 2. generate ATE, average direct and indirect effects from grf, DML, medoutcon algorithms

source("./codes/nlsy79/02_load_data.R")
library(pbapply)
library(medoutcon)

X <- nlsy79_nona %>%
  dplyr::select(male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,propsc_att20lin,good) %>%
  as.data.frame
Y <- nlsy79_nona$povprop %>% as.vector()
# Y <- nlsy79_nona$pov %>% as.vector()
W <- nlsy79_nona$att4ycoll20 %>% as.vector()
W_comp <- nlsy79_nona$compcoll25 %>% as.vector()


seed = 155
# =====================================
# ATE from casusal forests
# =====================================
set.seed(seed)
tot <- causal_forest(X, Y, W,
                      num.trees = 4000)
average_treatment_effect(tot,target.sample = "all",method="TMLE")
average_treatment_effect(tot,target.sample = "all",method="AIPW")


# =====================================
# Natural Direct and Indirect Effects
# from causal mediation forests
# =====================================
set.seed(seed)
med = med_causal_forest(as.matrix(X),Y,W = as.factor(W),M = as.vector(W_comp),
      num.trees=4000,min.node.size=25)
med$nde %>% mean
med$nie %>% mean
med_summary_effect(med)


# add clever covaraites M0 and M1 E(M | X, A = a) for a = 0,1
fit0 = regression_forest(X[W==0,],W_comp[W==0],num.trees=50)
fit1 = regression_forest(X[W==1,],W_comp[W==1],num.trees=50)
M0 = predict(fit0,newdata=X)$predictions
M1 = predict(fit1,newdata=X)$predictions
med = med_causal_forest(cbind(X,M0,M1),Y,W = as.factor(W),M = as.vector(W_comp),
      num.trees=4000,min.node.size=20)
med$nde %>% mean
med$nie %>% mean
med_summary_effect(med)


# version2: add clever covariate
fit = regression_forest(cbind(X,W),W_comp)
M0 = predict(fit,newdata=cbind(X,W=0))$predictions
M1 = predict(fit,newdata=cbind(X,W=1))$predictions
med = med_causal_forest(cbind(X,M0,M1),Y,W = as.factor(W),M = as.vector(W_comp),
      num.trees=4000,min.node.size=20)
med$nde %>% mean
med$nie %>% mean
med_summary_effect(med)

# =====================================
# Zhou (2022) DML method for
# ATE, CDE, NIE
# =====================================
set.seed(seed)
source("./codes/nlsy79/DirectIndirectEffect.R") # povprop
overall_grf <- overall
overall_grf
overall_ranger
set.seed(seed)
source("./codes/nlsy79/DirectIndirectEffect_ranger.R")
overall_ranger <- overall
overall_ranger


# =====================================
# Diaz (2021) DML + interventional 
# approach ATE, IDE, NIE
# One Step Approach
# =====================================
set.seed(seed) 
# Y lacks enough variations thus Y was incorrectly treated 
# as a discrete outcome by the algorithm without any adjustment
Y <- Y + runif(n = length(Y), min = 0.000001, max = 0.000009)

educ_nde_os_noz = medoutcon(W = X,
                     A = W,
                     Z = NULL,
                     M = W_comp,
                     Y = Y,
                     effect = "direct",
                     estimator = "onestep")
educ_nde_os_noz
educ_nde_os_noz %>% summary
educ_nde_os_noz %>% summary %>% .$param_est 

educ_nie_os_noz = medoutcon(W = X,
                     A = W,
                     Z = NULL,
                     M = W_comp,
                     Y = Y,
                     effect = "indirect",
                     estimator = "onestep")
educ_nie_os_noz
educ_nie_os_noz %>% summary
educ_nie_os_noz %>% summary %>% .$param_est 



# =====================================
# Diaz (2021) DML + interventional 
# TMLE with medoutcon
# =====================================
educ_nde_tmle_noz = medoutcon(W = X,
                     A = W,
                     Z = NULL,
                     M = W_comp,
                     Y = Y,
                     effect = "direct",
                     estimator = "tmle")
educ_nde_tmle_noz
educ_nde_tmle_noz %>% summary
educ_nde_tmle_noz %>% summary %>% .$param_est 
educ_nde_tmle_noz %>% summary %>% .$var_est %>% sqrt 


educ_nie_tmle_noz = medoutcon(W = X,
                     A = W,
                     Z = NULL,
                     M = W_comp,
                     Y = Y,
                     effect = "indirect",
                     estimator = "tmle")
educ_nie_tmle_noz
educ_nie_tmle_noz %>% summary
educ_nie_tmle_noz %>% summary %>% .$param_est 
educ_nie_tmle_noz %>% summary %>% .$var_est %>% sqrt


