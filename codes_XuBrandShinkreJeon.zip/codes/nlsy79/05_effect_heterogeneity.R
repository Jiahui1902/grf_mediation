# This script is to generate
# 1. variable importance from grf
# 2. plot variable importance
# 3. calibrate the heterogeneity with RATE
# 4. generate two summaty tables for the patterns of heterogeneity
#       a). effect estimates by covaraites
#       b). covaraite characteristics by effect estimates
# 5. compare the effect heterogeneity detected with DML

rm(list = ls())
source("./codes/nlsy79/02_load_data.R")
library("ggExtra")


X <- nlsy79_nona %>%
  dplyr::select(male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,propsc_att20lin,good) %>%
  as.data.frame
Y <- nlsy79_nona$povprop %>% as.vector()
W <- nlsy79_nona$att4ycoll20 %>% as.vector()
W_comp <- nlsy79_nona$compcoll25 %>% as.vector()


# =====================================
# step 0: grow forests
# =====================================
# causal forests for total effect
set.seed(137)
tot <- causal_forest(X, Y, W)
average_treatment_effect(tot)
# causal mediation forests for natural direct and indirect effects
seed = 29
set.seed(seed)
med = med_causal_forest(as.matrix(X),Y,W = as.factor(W),M = as.vector(W_comp),
      num.trees=4000,min.node.size=25)
med_summary_effect(med)



# =====================================
# step 1: omnibus test 
# =====================================

### method 1: regression method using test_calibration
# total effect
test_calibration(tot)
# equal to the following
target.tot = unname(tot$Y.orig - tot$Y.hat)
mean.pred.tot = unname(W - tot$W.hat) * mean(tot$predictions)
diff.pred.tot = unname(W - tot$W.hat) * (tot$predictions - mean(tot$predictions))
blp.tot = lm(target.tot ~ mean.pred.tot + diff.pred.tot + 0)
blp.summary.tot <- lmtest::coeftest(blp.tot,
    vcov = sandwich::vcovCL,
    type = "HC3"
  )
dimnames(blp.summary.tot)[[2]][4] <- gsub("[|]", "", dimnames(blp.summary.tot)[[2]][4])
blp.summary.tot[, 4] <- ifelse(blp.summary.tot[, 3] < 0, 1 - blp.summary.tot[, 4] / 2, blp.summary.tot[, 4] / 2)
blp.summary.tot   

# adapt the method and apply to natural direct and indirect effects
# direct effect
target.nde = unname(med$Y.orig - med$Y.hat)
mean.pred.nde = unname(W - med$W.hat[,2]) * mean(med$nde)
diff.pred.nde = unname(W - med$W.hat[,2]) * (med$nde - mean(med$nde))
pred.nie = unname(W_comp - med$M.hat) * (med$debiased.error)

blp.nde = lm(target.nde ~ mean.pred.nde + diff.pred.nde + pred.nie + 0)
blp.nde$coefficients <- blp.nde$coefficients[1:2]
blp.summary.nde <- lmtest::coeftest(blp.nde,
    vcov = sandwich::vcovCL,
    type = "HC3"
  )
dimnames(blp.summary.nde)[[2]][4] <- gsub("[|]", "", dimnames(blp.summary.nde)[[2]][4])
blp.summary.nde[, 4] <- ifelse(blp.summary.nde[, 3] < 0, 1 - blp.summary.nde[, 4] / 2, blp.summary.nde[, 4] / 2)
blp.summary.nde

# indirect effect
target.nie = unname(med$Y.orig - med$Y.hat - unname(W - med$W.hat[,2])*med$nde)
mean.pred.nie = unname(W - med$W.hat[,2]) * mean(med$nie)
diff.pred.nie = unname(W - med$W.hat[,2]) * (med$nie - mean(med$nie))

blp.nie = lm(target.nie ~ mean.pred.nie + diff.pred.nie + 0)
blp.summary.nie <- lmtest::coeftest(blp.nie,
    vcov = sandwich::vcovCL,
    type = "HC3"
  )
dimnames(blp.summary.nie)[[2]][4] <- gsub("[|]", "", dimnames(blp.summary.nie)[[2]][4])
blp.summary.nie[, 4] <- ifelse(blp.summary.nie[, 3] < 0, 1 - blp.summary.nie[, 4] / 2, blp.summary.nie[, 4] / 2)
blp.summary.nie   


### method 2: RATE metric (via sample splitting + cross-fitting)
seed = 35
# total effect
set.seed(seed)
N = nrow(nlsy79_nona)
train <- sample(1:N, floor(N / 2))
test <- -train
tot.train <- causal_forest(X[train, ], Y[train], W[train])
pred <- predict(tot.train, newdata = X[test, ])$predictions
tot.eval <- causal_forest(X[test, ], Y[test], W[test])
rate <- rank_average_treatment_effect(tot.eval, -pred)
rate
2*pnorm(-abs(rate$estimate/rate$std.err))


rate <- rank_average_treatment_effect(tot.eval, -pred,target="QINI")
rate
2*pnorm(-abs(rate$estimate/rate$std.err))

## follow the effect benefit from nde and nie
med.train <- med_causal_forest(cbind(X)[train,], Y[train], W[train],
             M = as.vector(W_comp)[train],num.trees=4000,min.node.size=20)
pred.nde <- predict(med.train,newdata = cbind(X)[test,])$predictions

rate.nde <- rank_average_treatment_effect(tot.eval, -pred.nde)
rate.nde
2*pnorm(-abs(rate.nde$estimate/rate.nde$std.err))

rate.nde <- rank_average_treatment_effect(tot.eval, -pred.nde, target = "QINI")
rate.nde
2*pnorm(-abs(rate.nde$estimate/rate.nde$std.err))


pred.nie <- predict(med.train$nie.forest,newdata = cbind(X)[test,])$predictions
rate.nie <- rank_average_treatment_effect(tot.eval, -pred.nie)
rate.nie
2*pnorm(-abs(rate.nie$estimate/rate.nie$std.err))

rate.nie <- rank_average_treatment_effect(tot.eval, -pred.nie, target = "QINI")
rate.nie
2*pnorm(-abs(rate.nie$estimate/rate.nie$std.err))


# =====================================
# step 2: variable importance
# =====================================
# total effect
imp.total <- tibble(variable=colnames(X),imp_ate=variable_importance(tot))
imp.total %>% arrange(imp_ate) %>% as.data.frame
# direct effect
imp.nde <- tibble(variable=colnames(X),imp_nde=variable_importance(med)[1:ncol(X)]) 
# indirect effect
imp.nie <- tibble(variable=colnames(X),imp_nie=variable_importance(med$nie.forest)[1:ncol(X)])

all_imp = cbind(imp.total,imp.nde[,2],imp.nie[,2])

all_imp$varlab <- lapply(all_imp$variable,function(i){
  x = nlsy79_nona %>% pull(i) %>% attr(.,"label")
  if(!is.null(x)){
    x
  }else{NA}}) %>% unlist
all_imp$varlab[which(all_imp$variable=="hisp")] <- "Hispanic"
all_imp$varlab[which(all_imp$variable=="propsc_att20lin")] <- "Propensity Score for Att."
all_imp$varlab[which(all_imp$variable=="black")] <- "Black"

all_imp = all_imp %>% arrange(imp_ate)

p79 = ggplot(all_imp %>% gather(type,importance,-varlab,-variable)%>%
              mutate(x = rep(1:23,3), type = factor(type,             
              labels = c("Total Effect","Natural Direct Effect","Natural Indirect Effect"))),
  aes(x=factor(x,labels = all_imp_79$varlab),y=importance,group=type))+
  geom_point(size=2)+
  facet_grid(~type)+
  theme_bw()+  
  coord_flip()+
  labs(y="Importance Score (% splits using a specific variable)",
       x="Variable Name",
       title = "A. NLSY 1979 Cohort")+
  ylim(0,0.35)+
  theme(text = element_text(size = 20),
        axis.text = element_text(size = 16))+
  theme(plot.margin = unit(c(1,1,1,1), "lines"),
        legend.position="bottom",
        legend.title=element_blank(),        
        legend.text = element_text(size=15),
        panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(color = "grey80",
                                        linewidth = 0.5,
                                        linetype = 2),
        panel.grid.minor = element_blank(),
        strip.background = element_blank(),
        strip.text.x = element_text(size = 20), # face = "bold"
        axis.line = element_line(linewidth = 0.5),
        plot.title = element_text(hjust=0.5,face="bold"))


# =====================================
# step 3: summarize heterogeneity 
# patterns in two ways:
# a). conditional effects by subgroups
## The most important three variables
## race
## parental income
## propensity score
#
## Summarize CATE by tree structure
#
# b). characteristics by effect ranks
## Method 1: Sample split and Cross-Fit
## Method 2: Leave one out prediction
# =====================================

# kept the name of df_rate to reuse the data frame for Appendix Tables
df_rate = nlsy79_nona
df_rate$ate = tot$predictions
df_rate$nde = med$nde
df_rate$nie = med$nie
df_rate$grf_ate_eif = get_scores(tot)
df_rate$grf_nde_eif = get_scores(med)$nde
df_rate$grf_nie_eif = get_scores(med)$nie
df_rate$log_parinc = log(df_rate$i_parinc + 1)
summary(df_rate$i_parinc)
summary(df_rate$log_parinc)

# a). conditional effects by subgroups
## ++++++++++++++++++++++++++++++++++
## race
## ++++++++++++++++++++++++++++++++++

## race: white
### total effect
(grf_white_1 = average_treatment_effect(tot,subset=(df_rate$black==0&df_rate$hisp==0)))
### direct effect and indirect
(grf_white_2 = med_summary_effect(med,subset=(df_rate$black==0&df_rate$hisp==0)))

## race: black
### total effect
(grf_black_1 = average_treatment_effect(tot,subset=(df_rate$black==1)))
### direct effect and indirect
(grf_black_2 = med_summary_effect(med,subset=(df_rate$black==1)))
2*pnorm(-abs(grf_black_1[1]/grf_black_1[2]))
2*pnorm(-abs(grf_black_2[,1]/grf_black_2[,2]))

## race: hisp
### total effect
(grf_hisp_1 = average_treatment_effect(tot,subset=(df_rate$hisp==1)))
### direct effect and indirect
(grf_hisp_2  = med_summary_effect(med,subset=(df_rate$hisp==1)))

eif = get_forest_weights(tot)
mean(eif[1,])
get_scores(tot) %>% head

# grf multiply robust adjustment scores
newX = data.frame(black=c(0,1,0),hisp=c(0,0,1))
# total effect
fit1 = lm(grf_ate_eif ~ black + hisp, data = df_rate)
(dml_tot = cbind(predict(fit1, newX, se.fit = TRUE)$fit,predict(fit1, newX, se.fit = TRUE)$se.fit))
# direct effect
fit2 = lm(grf_nde_eif ~ black + hisp, data = df_rate)
(dml_nde = cbind(predict(fit2, newX, se.fit = TRUE)$fit,predict(fit2, newX, se.fit = TRUE)$se.fit))
# indirect effect
fit3 = lm(grf_nie_eif ~ black + hisp, data = df_rate)
(dml_nie = cbind(predict(fit3, newX, se.fit = TRUE)$fit,predict(fit3, newX, se.fit = TRUE)$se.fit))

p1_race = tribble( ~ black, ~ hisp, ~effect, ~ est, ~se, ~ method, 
                    0, 0, "ate", grf_white_1[1],grf_white_1[2], "grf",
                    0, 0, "ate", dml_tot[1,1], dml_tot[1,2],"dml",            
                    0, 0, "nde", grf_white_2[1,1],grf_white_2[1,2], "grf",
                    0, 0, "nde", dml_nde[1,1], dml_nde[1,2],"dml",
                    0, 0, "nie", grf_white_2[2,1],grf_white_2[2,2], "grf",
                    0, 0, "nie", dml_nie[1,1], dml_nie[1,2],"dml", 
                            
                    1, 0, "ate", grf_black_1[1],grf_black_1[2], "grf",
                    1, 0, "ate", dml_tot[2,1], dml_tot[2,2],"dml",            
                    1, 0, "nde", grf_black_2[1,1],grf_black_2[1,2], "grf",
                    1, 0, "nde", dml_nde[2,1], dml_nde[2,2],"dml",
                    1, 0, "nie", grf_black_2[2,1],grf_black_2[2,2], "grf",
                    1, 0, "nie", dml_nie[2,1], dml_nie[2,2],"dml", 
                    
                    0, 1, "ate", grf_hisp_1[1],grf_hisp_1[2], "grf",
                    0, 1, "ate", dml_tot[3,1], dml_tot[3,2],"dml",            
                    0, 1, "nde", grf_hisp_2[1,1],grf_hisp_2[1,2], "grf",
                    0, 1, "nde", dml_nde[3,1], dml_nde[3,2],"dml",
                    0, 1, "nie", grf_hisp_2[2,1],grf_hisp_2[2,2], "grf",
                    0, 1, "nie", dml_nie[3,1], dml_nie[3,2],"dml", 
            )%>%
        mutate(method=factor(method,levels=c("grf","dml"),
                       labels = c("Causal Forests",
                                  "Double/Debiased Machine Learning")),
        race = factor(paste0(black,hisp),levels = c("00","10","01"), labels=c("White","Black","Hispanic")),
        effect = factor(effect,levels = c("ate","nde","nie"), labels = c("Total Effect","Natural Direct Effect","Natural Indirect Effect")))

p1.grf.79 = p1_race %>% filter(method == "Causal Forests",race!="Hispanic") %>%  
  ggplot(.,aes(x=race,y=est))+
  geom_point(mapping = aes(x=race,y=est,group=effect,color=effect),
                position=position_dodge(width=.3),size=3)+
  geom_errorbar(mapping=aes(ymin=est-1.96*se,ymax=est+1.96*se,
                       group=effect,color=effect,width=.1),
                       position=position_dodge(width=.3))+
  ylim(-0.21,0.05)+
  theme_light()+
  labs(x="Racial/Ethnic Groups",
       y="Conditional Average Effect")+
  geom_hline(yintercept = 0, color = "black",linetype="dashed",linewidth=1)+    
  theme_bw()+     
  scale_color_manual(name=NULL,values = c("black","red","blue"))+
  theme(axis.text = element_text(size=10),
          axis.title = element_text(face="bold",size=12),
          legend.text = element_text(size = 12,face="bold"))  
ggsave("./nlsy79_results/figure3.1_race_grf.pdf",plot = p1.grf.79, width = 12,height = 9)


## ++++++++++++++++++++++++++++++++++
## parental income 
## (cut parental income equally)
## ++++++++++++++++++++++++++++++++++
# check the distribution of parental income in original scales and log scales
summary(df_rate$i_parinc)
summary(df_rate$log_parinc)


p2.grf.79 = ggplot()+
    # ATE
    # geom_point(data = df_rate, mapping=aes(x = log_parinc, y = ate, color = "Total Effect"),alpha=.02)+
    stat_smooth(data = df_rate, mapping=aes(x = log_parinc, y = ate, color="Total Effect"),fill='black',alpha=0.3)+
    # NDE
    # geom_point(data = df_rate, mapping=aes(x = log_parinc, y = nde, color = "Direct Effect"), alpha=.02)+
    stat_smooth(data = df_rate, mapping=aes(x = log_parinc, y = nde, color = "Direct Effect"),fill='red',alpha=.3)+
    # NIE
    # geom_point(data = df_rate, mapping=aes(x = log_parinc, y = nie, color = "Indirect Effect"),alpha=.02)+
    stat_smooth(data = df_rate, mapping=aes(x = log_parinc, y = nie, color = "Indirect Effect"),fill='blue',alpha=.3)+    
    labs(x = "Parental Income (log)",
        y = "Conditional Average Effect")+
    scale_color_manual(name=NULL,
                       breaks = c("Total Effect","Direct Effect","Indirect Effect"),
                       values = c("black","red","blue"))+
    guides(color=guide_legend(override.aes=list(fill=NA)))+
    # xlim(0,175)+
    ylim(-0.21,0.05)+
    geom_hline(yintercept = 0, color = "black",linetype="dashed",linewidth=1)+ 
    theme_bw()+
    theme(axis.text = element_text(size=10),
          axis.title = element_text(face="bold",size=12),
          legend.text = element_text(size = 12,face="bold"))+
    scale_x_continuous(breaks = c(1,3,5))
ggsave("./nlsy79_results/figure3.1_inc_grf.pdf",plot = p2.grf.79, width = 12,height = 9)


## ++++++++++++++++++++++++++++++++++
## propensity scores
## ++++++++++++++++++++++++++++++++++
summary(df_rate$propsc_att20lin)
summary(df_rate$propsc_att4y20)

p3.grf.79 = ggplot()+
    # ATE
    # geom_point(data = df_rate, mapping=aes(x = propsc_att4y20, y = ate, color = "Total Effect"),alpha=.05)+
    stat_smooth(data = df_rate, mapping=aes(x = propsc_att4y20, y = ate, color="Total Effect"),fill='black',alpha=0.3)+
    # NDE
    # geom_point(data = df_rate, mapping=aes(x = propsc_att4y20, y = nde, color = "Direct Effect"), alpha=.05)+
    stat_smooth(data = df_rate, mapping=aes(x = propsc_att4y20, y = nde, color = "Direct Effect"),fill='red',alpha=.3)+
    # NIE
    # geom_point(data = df_rate, mapping=aes(x = propsc_att4y20, y = nie, color = "Indirect Effect"),alpha=.05)+
    stat_smooth(data = df_rate, mapping=aes(x = propsc_att4y20, y = nie, color = "Indirect Effect"),fill='blue',alpha=.3)+    
    labs(x = "Estimated Propensity Score",
        y = "Conditional Average Effect")+
    scale_color_manual(name="Effect",
                       breaks = c("Total Effect","Direct Effect","Indirect Effect"),
                       values = c("black","red","blue"))+    
    guides(color=guide_legend(override.aes=list(fill=NA)))+
    ylim(-0.21,0.05)+
    geom_hline(yintercept = 0, color = "black",linetype="dashed",linewidth=1)+ 
    theme_bw()+
    theme(axis.text = element_text(size=10),
          axis.title = element_text(face="bold",size=12),
          legend.text = element_text(size = 12,face="bold"))
ggsave("./nlsy79_results/figure3.1_propsc_grf.pdf",plot = p3.grf.79, width = 12,height = 9)

## +++++++++++++++++++++++++
# combined the three figures
## +++++++++++++++++++++++++
ggpubr::ggarrange(p1.grf.79,p2.grf.79,p3.grf.79, 
          # labels = c("A", "B", "C"),
          ncol = 3, nrow = 1,common.legend = TRUE, legend = "bottom")         
ggsave("./nlsy79_results/figure3_summaryeffects_79.pdf",width = 12,height = 4.2)

load("workingdata/97_povprop_cate.Rdata")
library(ggpubr)
plot.79 = ggpubr::ggarrange(p1.grf.79,p2.grf.79,p3.grf.79, 
          # labels = c("A", "B", "C"),
          ncol = 3, nrow = 1,common.legend = TRUE, legend = "none")         
plot.79 = ggpubr::annotate_figure(plot.79,top = text_grob("NLSY 1979 Cohort",face=c("bold","italic"),size=16))
plot.97 = ggpubr::ggarrange(p1.grf,p2.grf,p3.grf, 
          # labels = c("A", "B", "C"),
          ncol = 3, nrow = 1,common.legend = TRUE, legend = "bottom")         
plot.97 = ggpubr::annotate_figure(plot.97,top = text_grob("NLSY 1997 Cohort",face=c("bold","italic"),size=16))
ggpubr::ggarrange(plot.79,plot.97,ncol=1,common.legend = TRUE, legend = "bottom")
ggsave("./nlsy79_results/figure3_summaryeffects.pdf",width = 12,height = 8)


## +++++++++++++++++++++++++
### Summarize CATE
### by tree structure
## +++++++++++++++++++++++++
### by tree structure

# install.packages("rpart.plot")
# install.packages("dichromat")
# install.packages("partykit")
# install.packages("data.tree")
install.packages("DiagrammeR")
library(rpart)
library(rpart.plot)
library("dichromat")
library(partykit)
library(data.tree)

#### ------------
#### Total Effect
#### ------------
tree = rpart(as.formula(paste0("ate ~ ", paste(colnames(X),collapse="+"))), 
    df_rate)
tree

# get splitting rules to calculate CATEs
prty = as.party(tree)
opfit_tree = as.Node(prty)
x_num <- 0
hte_effect = list()
opfit_tree$Do(function(node){    
    cate = average_treatment_effect(tot,
        subset = (1:nrow(df_rate))%in%as.numeric(rownames(node$data)) )
    x_num <<- x_num + 1
    hte_effect[[x_num]] <<- cate
})

hte_effect = bind_rows(hte_effect)
hte_effect$pvalue = 2*pnorm(-abs(hte_effect$estimate/hte_effect$std.err))
hte_effect$stars                         = "   "
hte_effect$stars[hte_effect$pvalue<.05]  = "*  "
hte_effect$stars[hte_effect$pvalue<.01]  = "** "
hte_effect$stars[hte_effect$pvalue<.001] = "***"
hte_effect

tree$frame$yval = hte_effect$estimate


tree$frame$var[tree$frame$var=="black"] = "Black"
tree$frame$var[tree$frame$var=="propsc_att20lin"] = "Linearized Propensity Score"
tree$frame$var[tree$frame$var=="i_abil"] = "ASVAB Scale"
tree$frame$var[tree$frame$var=="i_parinc"] = "Parental Income"
tree$frame$var[tree$frame$var=="i_daded"] = "Father's Education"

rbPal = colorRampPalette(c("red","golden rod","blue"))
od = 1:length(tree$frame$yval)
cols = rbPal(length(tree$frame$yval))[od]
tree1 = tree
tree1$frame$yval = round(tree1$frame$yval,3)
pdf("nlsy79_results/figure4_tot_79.pdf",width=12,height=8)
prp(tree1,type = 1,nn=FALSE,box.palette = cols,digits = 3,
    suffix = ifelse(str_sub(sprintf("%.3f",tree1$frame$yval),-1)==0,
                    paste0("0",hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100)),
                    paste0(hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100))),
    yesno = 2, yes.text = "y", no.text = "no", 
    trace = TRUE, varlen = 0,
    col = "white")
dev.off()




#### ------------
#### Direct Effect
#### ------------
tree = rpart(as.formula(paste0("nde ~ ", paste(colnames(X),collapse="+"))), 
    df_rate)
tree

# get splitting rules to calculate CATEs
prty = as.party(tree)
opfit_tree = as.Node(prty)
x_num <- 0
hte_effect = list()
opfit_tree$Do(function(node){    
    cate = med_summary_effect(med,
        subset = (1:nrow(df_rate))%in%as.numeric(rownames(node$data)) )
    x_num <<- x_num + 1
    hte_effect[[x_num]] <<- cate[1,]
})

hte_effect = bind_rows(hte_effect)
hte_effect$pvalue = 2*pnorm(-abs(hte_effect$estimate/hte_effect$std.err))
hte_effect$stars                         = "   "
hte_effect$stars[hte_effect$pvalue<.05]  = "*  "
hte_effect$stars[hte_effect$pvalue<.01]  = "** "
hte_effect$stars[hte_effect$pvalue<.001] = "***"
hte_effect

tree$frame$yval = hte_effect$estimate


tree$frame$var[tree$frame$var=="black"] = "Black"
tree$frame$var[tree$frame$var=="propsc_att20lin"] = "Linearized Propensity Score"
tree$frame$var[tree$frame$var=="i_abil"] = "ASVAB Scale"
tree$frame$var[tree$frame$var=="i_parinc"] = "Parental Income"
tree$frame$var[tree$frame$var=="i_sibsz"] = "Sibling Size"

rbPal = colorRampPalette(c("red","golden rod","blue"))
od = 1:length(tree$frame$yval)
cols = rbPal(length(tree$frame$yval))[od]
tree1 = tree
tree1$frame$yval = round(tree1$frame$yval,3)
pdf("nlsy79_results/figure4_nde_79.pdf",width=12,height=8)
prp(tree1,type = 1,nn=FALSE,box.palette = cols,digits = 3,
    suffix = ifelse(str_sub(sprintf("%.3f",tree1$frame$yval),-1)==0,
                    paste0("0",hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100)),
                    paste0(hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100))),
    yesno = 2, yes.text = "y", no.text = "no", 
    trace = TRUE, varlen = 0,
    col = "white")
dev.off()

#### ------------
#### Indirect Effect
#### ------------
tree = rpart(as.formula(paste0("nie ~ ", paste(colnames(X),collapse="+"))), 
    df_rate)
tree
opcp = 0.02
tree = prune(tree,opcp)
tree$frame$yval %>% length

# get splitting rules to calculate CATEs
prty = as.party(tree)
opfit_tree = as.Node(prty)
x_num <- 0
hte_effect = list()
opfit_tree$Do(function(node){    
    cate = med_summary_effect(med,
        subset = (1:nrow(df_rate))%in%as.numeric(rownames(node$data)) )
    x_num <<- x_num + 1
    hte_effect[[x_num]] <<- cate[2,]
})

hte_effect = bind_rows(hte_effect)
hte_effect$pvalue = 2*pnorm(-abs(hte_effect$estimate/hte_effect$std.err))
hte_effect$stars                         = "   "
hte_effect$stars[hte_effect$pvalue<.05]  = "*  "
hte_effect$stars[hte_effect$pvalue<.01]  = "** "
hte_effect$stars[hte_effect$pvalue<.001] = "***"
hte_effect

tree$frame$yval = hte_effect$estimate


tree$frame$var[tree$frame$var=="male"] = "Male"
tree$frame$var[tree$frame$var=="black"] = "Black"
tree$frame$var[tree$frame$var=="propsc_att20lin"] = "Linearized Propensity Score"
tree$frame$var[tree$frame$var=="i_abil"] = "ASVAB Scale"
tree$frame$var[tree$frame$var=="i_parinc"] = "Parental Income"
tree$frame$var[tree$frame$var=="i_schdisadv"] = "School Disadvantage"

rbPal = colorRampPalette(c("red","golden rod","blue"))
od = 1:length(tree$frame$yval)
cols = rbPal(length(tree$frame$yval))[od]
tree1 = tree
tree1$frame$yval = round(tree1$frame$yval,3)
pdf("nlsy79_results/figure4_nie_79.pdf",width=12,height=8)
prp(tree1,type = 1,nn=FALSE,box.palette = cols,digits = 3,
    suffix = ifelse(str_sub(sprintf("%.3f",tree1$frame$yval),-1)==0,
                    paste0("0",hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100)),
                    paste0(hte_effect$stars, # significance
                    '\n (',round(hte_effect$std.err,3),')',  # se
                    '\n Size (%) = ',sprintf("%.1f",round(tree$frame$n/nrow(X),3)*100))),
    yesno = 2, yes.text = "y", no.text = "no", 
    trace = TRUE, varlen = 0,
    col = "white")
dev.off()





### +++++++++++++++++++++++++++++++++++
# b). characteristics by effect ranks
#### Method 1: Sample split and Cross-Fit
#### Method 2: Leave one out prediction
### +++++++++++++++++++++++++++++++++++
#### Method 1: Sample split and Cross-Fit
## total effect
## direct effect
## indirect effect
N = nrow(nlsy79_nona)
train <- sample(1:N, floor(N * 1 / 2))
test <- -train
# Causal Forests
tot.train <- causal_forest(X[train, ], Y[train], W[train])
# Causal Mediation Forests
med.train <- med_causal_forest(cbind(X)[train,], Y[train], W[train],
             M = as.vector(W_comp)[train],num.trees=4000,min.node.size=20)

## cross-fitting
## tot
pred <- predict(tot.train, newdata = X[test, ])$predictions
## nde
pred.nde <- predict(med.train,newdata = cbind(X)[test,])$predictions
## nie
pred.nie <- predict(med.train$nie.forest,newdata = cbind(X)[test,])$predictions


library(gtsummary)
ntiles = 5

g = cut(order(order(pred)),seq(min(order(order(pred))),max(order(order(pred))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
g %>% table
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)#[test,]
Xtest$g = g
totXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20,everything()),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

totXexport %>% as_hux_table

totXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()



g = cut(order(order(pred.nde)),seq(min(order(order(pred.nde))),max(order(order(pred.nde))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)#[test,]
Xtest$g = g
ndeXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

ndeXexport %>% as_hux_table

ndeXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()


g = cut(order(order(pred.nie)),seq(min(order(order(pred.nie))),max(order(order(pred.nie))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)#[test,]
Xtest$g = g
nieXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

nieXexport %>% as_hux_table

nieXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()


#### ------------
#### leave-one-out-prediction
#### ------------
#### Method 2: Leave one out prediction (run the leave one out prediction file first and then summarize the characteristics)
list.files("./workingdata/loov_79/")

loov = read_table("./workingdata/loov_79/79_leave_one_out_prediction1.txt",
  col_names = c("id","ate","nde","nie"),col_types = list("i","d","d","d"))

loov = map(list.files("./workingdata/loov_79/",full.names = TRUE),
  ~read_table(.x,
  col_names = c("id","ate","nde","nie"),col_types = list("i","d","d","d"))
)
loov = bind_rows(loov)
loov = loov[((loov$id)%in%(1:3456)), ] %>% arrange(id)

loov$ate %>% mean
loov$nde %>% mean(.,na.rm = TRUE)
loov$nie %>% mean(.,na.rm = TRUE)
tot$predictions %>% mean
med$nde %>% mean
med$nie %>% mean
cor(loov$ate,tot$predictions)
summary(loov$ate-tot$predictions)
summary(loov$nde-med$nde)
summary(loov$nie-med$nie)


pred = loov$ate
pred.nde = ifelse(is.na(loov$nde),med$nde,loov$nde)
pred.nie = ifelse(is.na(loov$nie),med$nie,loov$nie)
cor(pred.nde,med$nde)
cor(pred.nie,med$nie)

ntiles = 5
g = cut(order(order(pred)),seq(min(order(order(pred))),max(order(order(pred))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
g %>% table
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)
Xtest$g = g
totXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20,everything()),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

totXexport %>% as_hux_table

totXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()



g = cut(order(order(pred.nde)),seq(min(order(order(pred.nde))),max(order(order(pred.nde))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)
Xtest$g = g
ndeXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20,everything()),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

ndeXexport %>% as_hux_table

ndeXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()


g = cut(order(order(pred.nie)),seq(min(order(order(pred.nie))),max(order(order(pred.nie))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
Xtest = cbind(X,propsc_att4y20=df_rate$propsc_att4y20)
Xtest$g = g
nieXexport = tbl_summary(Xtest %>% 
             dplyr::select(g,black,i_parinc,propsc_att4y20,everything()),
             by = g,
             label = list(black ~ "Black",
                         i_parinc ~ "Parental Income",
                         propsc_att4y20 ~ "Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),                          
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

nieXexport %>% as_hux_table
summary(X$i_parinc)

nieXexport %>% as_gt() %>%
  gt::as_latex() %>% 
  cat()



