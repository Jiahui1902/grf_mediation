
library(optparse)
library("TeachingDemos")
library(stringr)
library(grf)

option_list <- list(
	make_option("--v", default="version1"),
	make_option("--loov", default=1)
)
opts <- parse_args(OptionParser(option_list=option_list))
testversion <- opts$v
loov <- as.numeric(opts$loov)
print(loov)

Sys.time()

source("./codes/nlsy79/02_load_data.R")

X <- nlsy79_nona %>%
  dplyr::select(male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,propsc_att20lin,good) %>%
  as.data.frame
Y <- nlsy79_nona$povprop %>% as.vector()
W <- nlsy79_nona$att4ycoll20 %>% as.vector()
W_comp <- nlsy79_nona$compcoll25 %>% as.vector()


# leave one out cross-fitting
df_result = vector(mode = "list",length=20)
l = ((20*(loov-1)+1):(20*loov))
if (loov == 173){
    l = 3441:3456
    df_result = vector(mode = "list",length=16)
}

sink(file = paste0("./workingdata/loov_79/79_leave_one_out_prediction",loov,".txt"))
for(i in l ){
  med = med_causal_forest(as.matrix(X[-i,]),Y[-i],W = as.factor(W[-i]),M = as.vector(W_comp[-i]),num.trees=4000,min.node.size=20)  
  cf = causal_forest(as.matrix(X[-i,]),Y[-i], W[-i], num.trees = 2000)
  
  fit = c(ate = predict(cf,X[i,])$predictions, 
                     nde = predict(med,X[i,])$predictions[,,1],
                     nie = predict(med$nie.forest,X[i,])$predictions[,,1] )
  cat(c(i, fit))
  cat("\n")
  df_result[[i]] = fit
  
  if (i %% 10 == 0){
  gc()
  }
}
sink()

df_result %>% bind_rows %>% colMeans(.,na.rm=TRUE)

Sys.time()



txtStop()
