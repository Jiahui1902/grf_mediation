
# This script conducts sensitivity analysis

fit0 = regression_forest(X[W==0,],W_comp[W==0],num.trees=50)
fit1 = regression_forest(X[W==1,],W_comp[W==1],num.trees=50)
M0 = predict(fit0,newdata=X)$predictions
M1 = predict(fit1,newdata=X)$predictions

# population average
results <- data.frame(estimand = c("ate","nde","nie","cme", "atm"),
                      est = c(average_treatment_effect(tot)[1],med_summary_effect(med)[,1],mean(med$debiased.error[,1]),mean(M1)),
                      se = c(average_treatment_effect(tot)[2],med_summary_effect(med)[,2],med$debiased.error[,1]%>%sd,sd(M1)))

# sensitivity by race
results_white <- data.frame(estimand = c("ate","nde","nie","cme", "atm"),
                      est = c(average_treatment_effect(tot,subset = (X$black==0&X$hisp==0))[1],
                              med_summary_effect(med,subset = (X$black==0&X$hisp==0))[,1],                              
                              mean(med$debiased.error[(X$black==0&X$hisp==0),1]),
                              mean(M1[(X$black==0&X$hisp==0)])),
                      se  = c(average_treatment_effect(tot,subset = (X$black==0&X$hisp==0))[2],
                              med_summary_effect(med,subset = (X$black==0&X$hisp==0))[,2],
                              med$debiased.error[(X$black==0&X$hisp==0),1]%>%sd,
                              sd(M1[(X$black==0&X$hisp==0)])))
results_black <- data.frame(estimand = c("ate","nde","nie","cme", "atm"),
                      est = c(average_treatment_effect(tot,subset = (X$black==1&X$hisp==0))[1],
                              med_summary_effect(med,subset = (X$black==1&X$hisp==0))[,1],                              
                              mean(med$debiased.error[(X$black==1&X$hisp==0),1]),
                              mean(M1[(X$black==1&X$hisp==0)])),
                      se  = c(average_treatment_effect(tot,subset = (X$black==1&X$hisp==0))[2],
                              med_summary_effect(med,subset = (X$black==1&X$hisp==0))[,2],
                              med$debiased.error[(X$black==1&X$hisp==0),1]%>%sd,
                              sd(M1[(X$black==1&X$hisp==0)])))

# most responsive group
ntiles = 5
g.ate = cut(order(order(pred)),seq(min(order(order(pred))),max(order(order(pred))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
g.nde = cut(order(order(pred.nde)),seq(min(order(order(pred.nde))),max(order(order(pred.nde))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
g.nie = cut(order(order(pred.nie)),seq(min(order(order(pred.nie))),max(order(order(pred.nie))),length.out=(ntiles+1)),include.lowest=TRUE)%>%as.numeric 
results_q1 <- data.frame(estimand = c("ate","nde","nie","cme", "atm"),
                      est = c(average_treatment_effect(tot,subset = (g.ate==1))[1],
                              med_summary_effect(med,subset = (g.ate==1))[,1],                                                            
                              mean(med$debiased.error[(g.ate==1),1]),
                              mean(M1[(g.ate==1)])),
                      se  = c(average_treatment_effect(tot,subset = (g.ate==1))[2],
                              med_summary_effect(med,subset = (g.ate==1))[,2],
                              med$debiased.error[(g.ate==1),1]%>%sd,
                              sd(M1[(g.ate==1)])))


#### Sensitivity parameters
delta <- c(-0.3, -0.2, -0.1, 0.1, 0.2, 0.3)
gamma <- c(0.1, 0.2, 0.3)
alpha <- c(-0.2, 0.2)
beta <- c(0.1, 0.2)

### ++++++++++++++++++++++++++++++++++++++++
#### Population
### ++++++++++++++++++++++++++++++++++++++++
sen_table = expand.grid(
  estimand = c("ate", "nde", "cme", "atm","nie"),
  gamma = gamma, delta = delta, beta=beta,alpha = alpha) %>%
  left_join(results, by = c("estimand")) %>%
  mutate(adj = case_when(estimand=="nde" ~ est - delta * gamma + alpha * beta * est[estimand == "atm"],
                         estimand=="nie" ~ est - alpha * beta * est[estimand == "atm"],
                         estimand=="atm" ~ est, # completion probability (correctly measured by assumption)
                         TRUE ~ est - delta * gamma)) %>%
  select(-est) %>%
  pivot_wider(names_from = c("estimand"), values_from = "adj") %>%
  mutate(bias_total = delta * gamma,
         bias_nde   = delta * gamma - alpha * beta * (results$est[5]),
         bias_nie   = alpha * beta * (results$est[5])) %>%
  select(delta, gamma, alpha, beta, bias_total, bias_nde, bias_nie, everything())

# export the full version
left_join(
  sen_table %>% 
    select(delta,gamma,alpha, beta, bias_total, bias_nde, bias_nie, ate) %>% na.omit,
  sen_table %>% 
    select(delta,gamma,alpha, beta, bias_total, bias_nde, bias_nie, nde) %>% na.omit) %>% 
    left_join(.,
  sen_table %>% 
    select(delta,gamma,alpha, beta, bias_total, bias_nde, bias_nie, nie) %>% na.omit) %>%
  as.data.frame %>% 
  knitr::kable(., format = "latex",digits=3,linesep = c(""))

# export the short version
sen_table = expand.grid(
  estimand = c("ate", "nde", "cme", "atm","nie"),
  gamma = gamma, delta = delta) %>%
  mutate(alpha = delta, beta = gamma) %>%
  left_join(results, by = c("estimand")) %>%
  mutate(adj = case_when(estimand=="nde" ~ est - delta * gamma + alpha * beta * est[estimand == "atm"],
                         estimand=="nie" ~ est - alpha * beta * est[estimand == "atm"],
                         estimand=="atm" ~ est, # completion probability (correctly measured by assumption)
                         TRUE ~ est - delta * gamma)) %>%
  select(-est) %>%
  pivot_wider(names_from = c("estimand"), values_from = "adj") %>%
  mutate(bias_total = delta * gamma,
         bias_nde   = delta * gamma - alpha * beta * (results$est[5]),
         bias_nie   = alpha * beta * (results$est[5])) %>%
  select(delta, gamma, alpha, beta, bias_total, bias_nde, bias_nie, everything())


left_join(
  sen_table %>% 
    select(delta,gamma,bias_total, bias_nde, bias_nie, ate) %>% na.omit,
  sen_table %>% 
    select(delta,gamma,bias_total, bias_nde, bias_nie, nde) %>% na.omit) %>% 
    left_join(.,
  sen_table %>% 
    select(delta,gamma,bias_total, bias_nde, bias_nie, nie) %>% na.omit) %>%
  as.data.frame %>% 
  knitr::kable(., format = "latex",digits=3,linesep = c(""))


### ++++++++++++++++++++++++++++++++++++++++
### By race
### ++++++++++++++++++++++++++++++++++++++++
sen_table_white = expand.grid(
  estimand = c("ate", "nde", "cme", "atm","nie"),
  gamma = gamma, delta = delta) %>%
  mutate(alpha = delta, beta = gamma) %>%
  left_join(results_white, by = c("estimand")) %>%
  mutate(adj = case_when(estimand=="nde" ~ est - delta * gamma + alpha * beta * est[estimand == "atm"],
                         estimand=="nie" ~ est - alpha * beta * est[estimand == "atm"],
                         estimand=="atm" ~ est, # completion probability (correctly measured by assumption)
                         TRUE ~ est - delta * gamma)) %>%
  select(-est) %>%
  pivot_wider(names_from = c("estimand"), values_from = "adj") %>%
  mutate(bias_total = delta * gamma,
         bias_nde   = delta * gamma - alpha * beta * (results_white$est[5]),
         bias_nie   = alpha * beta * (results_white$est[5])) %>%
  select(delta, gamma, alpha, beta, bias_total, bias_nde, bias_nie, everything())

sen_table_black = expand.grid(
  estimand = c("ate", "nde", "cme", "atm","nie"),
  gamma = gamma, delta = delta) %>%
  mutate(alpha = delta, beta = gamma) %>%
  left_join(results_black, by = c("estimand")) %>%
  mutate(adj = case_when(estimand=="nde" ~ est - delta * gamma + alpha * beta * est[estimand == "atm"],
                         estimand=="nie" ~ est - alpha * beta * est[estimand == "atm"],
                         estimand=="atm" ~ est, # completion probability (correctly measured by assumption)
                         TRUE ~ est - delta * gamma)) %>%
  select(-est) %>%
  pivot_wider(names_from = c("estimand"), values_from = "adj") %>%
  mutate(bias_total = delta * gamma,
         bias_nde   = delta * gamma - alpha * beta * (results_black$est[5]),
         bias_nie   = alpha * beta * (results_black$est[5])) %>%
  select(delta, gamma, alpha, beta, bias_total, bias_nde, bias_nie, everything())

t_white = left_join(
    sen_table_white %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, ate) %>% na.omit,
    sen_table_white %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nde) %>% na.omit) %>% 
      left_join(.,
    sen_table_white %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nie) %>% na.omit) %>%
    as.data.frame

t_black = left_join(
    sen_table_black %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, ate) %>% na.omit,
    sen_table_black %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nde) %>% na.omit) %>% 
      left_join(.,
    sen_table_black %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nie) %>% na.omit) %>%
    as.data.frame

cbind(t_black,
  t_white[,(c("ate","nde","nie"))]%>%`colnames<-`(c("ate_white","nde_white","nie_white")))%>% 
  knitr::kable(., format = "latex",digits=3,linesep = c(""))


### ++++++++++++++++++++++++++++++++++++++++
#### Most responsive group
### ++++++++++++++++++++++++++++++++++++++++
sen_table_q1 = expand.grid(
  estimand = c("ate", "nde", "cme", "atm","nie"),
  gamma = gamma, delta = delta) %>%
  mutate(alpha = delta, beta = gamma) %>%
  left_join(results_q1, by = c("estimand")) %>%
  mutate(adj = case_when(estimand=="nde" ~ est - delta * gamma + alpha * beta * est[estimand == "atm"],
                         estimand=="nie" ~ est - alpha * beta * est[estimand == "atm"],
                         estimand=="atm" ~ est, # completion probability (correctly measured by assumption)
                         TRUE ~ est - delta * gamma)) %>%
  select(-est) %>%
  pivot_wider(names_from = c("estimand"), values_from = "adj") %>%
  mutate(bias_total = delta * gamma,
         bias_nde   = delta * gamma - alpha * beta * (results_q1$est[5]),
         bias_nie   = alpha * beta * (results_q1$est[5])) %>%
  select(delta, gamma, alpha, beta, bias_total, bias_nde, bias_nie, everything())

left_join(
    sen_table_q1 %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, ate) %>% na.omit,
    sen_table_q1 %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nde) %>% na.omit) %>% 
      left_join(.,
    sen_table_q1 %>% 
      select(delta,gamma,bias_total, bias_nde, bias_nie, nie) %>% na.omit) %>%
    as.data.frame %>%
    knitr::kable(., format = "latex",digits=3,linesep = c(""))




