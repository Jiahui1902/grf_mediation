# This script is to generate:
# descriptive statistics in the Empirical Example section

source("./codes/nlsy79/02_load_data.R")
library(gtsummary)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# table 2: summary statistics for the empirical example 
# Four columns Attendance Vs. Non Attendance 
# ( Comp | Att = 1) Vs. (Non Comp | Att = 1)
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# by treatment status
tbl_version3_1.1 <- tbl_summary(nlsy79_nona %>% 
              dplyr::select(att4ycoll20,pov,povprop
              ) %>% 
              mutate(att4ycoll20=ifelse(att4ycoll20==1,"Att.", "No Att.")),
            by = att4ycoll20,
            label = list(pov ~ "Poverty (Binary)",
                         povprop ~ "Prop. of Time in Poverty (Continuous)"),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),
             type = list(povprop ~ "continuous"),
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

tbl_version3_1.2 <- tbl_summary(nlsy79_nona %>% 
              dplyr::select(att4ycoll20,
              male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,propsc_att4y20,propsc_att20lin,good
              ) %>% 
              mutate(att4ycoll20=ifelse(att4ycoll20==1,"Att.", "No Att.")),
            by = att4ycoll20,
            label = list(male ~ "Male",
                          black ~ "Black",
                          hisp ~ "Hispanic",
                          i_daded ~ "Father's Education",
                          i_momed ~ "Mother's Education",
                          i_parinc ~ "Parents' Income",
                          i_daduwhcol ~ "Father Upper-White Collar",                         
                          i_intact ~ "Two-Parent Family",                         
                          i_sibsz ~ "Number of Siblings",
                          i_rural ~ "Rural Residence Age 14",
                          i_south ~ "Southern Residence Age 14",
                          i_abil ~ "ASVAB Ability",
                          i_mar18 ~ "Married by Age 18",
                          i_parent18 ~ "Had Children by Age 18",
                          i_hsprog ~ "College Prep. Program",
                          i_delinq ~ "Delinquency Scale",
                          i_schdisadv ~ "School Disadvantage",
                          i_eduexp ~ "Expects College",
                          i_eduasp ~ "Aspires College",
                          i_freduasp ~ "Friends Aspire College",
                          i_rotter ~ "Low Control",
                          good ~ "All Missing Values",
                          propsc_att4y20 ~ "Propensity Score for Att.",
                          propsc_att20lin ~ "Linearized Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),             
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")


# by mediator status given treatment 
tbl_version3_2.1 <- tbl_summary(nlsy79_nona %>% 
              dplyr::select(att4ycoll20,compcoll25,
                pov,povprop
              ) %>% 
              filter(att4ycoll20 == 1) %>%
              dplyr::select(-att4ycoll20) %>%
              mutate(compcoll25=ifelse(compcoll25==1,"Col. Comp.", "No Col. Comp.")),
            by = compcoll25,
            label = list(pov ~ "Poverty (Binary)",
                         povprop ~ "Prop. of Time in Poverty (Continuous)"),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),
             type = list(povprop ~ "continuous"),
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

tbl_version3_2.2 <- tbl_summary(nlsy79_nona %>% 
              dplyr::select(att4ycoll20,compcoll25,
                male,black,hisp,i_daded,i_momed,i_parinc,
                i_daduwhcol, i_intact, i_sibsz, i_rural, i_south, i_abil,
                i_hsprog, i_eduexp, i_eduasp, i_freduasp, i_rotter, i_delinq,
                i_schdisadv, i_mar18, i_parent18,propsc_att4y20,propsc_att20lin,good
              ) %>% 
              filter(att4ycoll20 == 1) %>%
              dplyr::select(-att4ycoll20) %>%
              mutate(compcoll25=ifelse(compcoll25==1,"Col. Comp.", "No Col. Comp.")),
            by = compcoll25,
            label = list(male ~ "Male",
                          black ~ "Black",
                          hisp ~ "Hispanic",
                          i_daded ~ "Father's Education",
                          i_momed ~ "Mother's Education",
                          i_parinc ~ "Parents' Income",
                          i_daduwhcol ~ "Father Upper-White Collar",                         
                          i_intact ~ "Two-Parent Family",                         
                          i_sibsz ~ "Number of Siblings",
                          i_rural ~ "Rural Residence Age 14",
                          i_south ~ "Southern Residence Age 14",
                          i_abil ~ "ASVAB Ability",
                          i_mar18 ~ "Married by Age 18",
                          i_parent18 ~ "Had Children by Age 18",
                          i_hsprog ~ "College Prep. Program",
                          i_delinq ~ "Delinquency Scale",
                          i_schdisadv ~ "School Disadvantage",
                          i_eduexp ~ "Expects College",
                          i_eduasp ~ "Aspires College",
                          i_freduasp ~ "Friends Aspire College",
                          i_rotter ~ "Low Control",
                          good ~ "All Missing Values",
                          propsc_att4y20 ~ "Propensity Score for Att.",
                          propsc_att20lin ~ "Linearized Propensity Score for Att."),
             statistic = list(all_continuous() ~ "{mean} ({sd})",
                          all_categorical() ~ "{p}%"),
            #  type = list(povprop ~ "continuous"),
             digits = list(all_continuous() ~ 2,
                           all_categorical() ~ 2)) %>% 
  modify_header(label ~ "**Variables**")

tbl_stack(list(
  tbl_merge(list(tbl_version3_1.1,tbl_version3_2.1)),
  tbl_merge(list(tbl_version3_1.2,tbl_version3_2.2))
),group_header = c("Outcome","Pre-Treatment Characteristics")) %>% as_hux_table

sink(file = "nlsy79_results/table_descriptive.txt")
tbl_stack(list(
  tbl_merge(list(tbl_version3_1.1,tbl_version3_2.1)),
  tbl_merge(list(tbl_version3_1.2,tbl_version3_2.2))
),group_header = c("Outcome","Pre-Treatment Characteristics")) %>% 
  as_gt() %>%
  gt::as_latex() %>% 
  cat()
sink()

tbl_stack(list(
  tbl_merge(list(tbl_version3_1.1,tbl_version3_2.1)),
  tbl_merge(list(tbl_version3_1.2,tbl_version3_2.2))
),group_header = c("Outcome","Pre-Treatment Characteristics")) %>%
as_hux_xlsx("nlsy79_results/table3_1979.xlsx")
