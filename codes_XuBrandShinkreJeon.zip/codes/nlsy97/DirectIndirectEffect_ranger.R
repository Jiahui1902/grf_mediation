library(haven)
library(survey)
library(gbm)
library(ranger)
library(rlang)
library(glmnet)
library(rsample)
library(caret)
library(tidyverse)
# library(mice)
library(SuperLearner)
library(Hmisc)
if(Sys.info()["user"]=="jiahuixu"){
  setwd("/Users/jiahuixu/Dropbox/_research/grf_mediation")
  source("./codes/zmisc.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="xujiahui"){
  setwd("/Users/xujiahui/Dropbox/_research/grf_mediation")
  source("./codes/zmisc.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="jpx5053"){
  setwd("/storage/work/jpx5053/research/grf_mediation")
  source("./codes/zmisc.R",encoding = "utf-8")
}



##########################################################
# Formulas for treatment, mediator, and outcome models
##########################################################
xvars <- exprs(male,black,hisp,i_daded,i_momed,i_parinc,i_intact,i_sibsz,
               i_rural,i_south,i_abil,good,i_gpa,i_hsprog,i_schsafe,i_tchgd,
               i_freduasp,i_delinq,i_mar18,i_parent18,propsc_att20lin)

# zvars <- exprs(propemp2025)
zvars <- NULL

avar <- expr(att4ycoll20)
mvar <- expr(compcoll25)
yvar <- expr(povprop)

# A ~ X
a_rhs <- xvars %>%
  reduce(~ expr(!!.x + !!.y))
a_form <- as.formula(expr(!!avar ~ !!a_rhs))

# Y ~ X + A
y_rhs <- c(xvars, avar) %>%
  reduce(~ expr(!!.x + !!.y))
y_form <- as.formula(expr(!!yvar ~ !!y_rhs))

# Y ~ X + Z + M | A = 1
y1_rhs <- c(xvars, zvars, mvar) %>%
  reduce(~ expr(!!.x + !!.y))
y1_form <- as.formula(expr(!!yvar ~ !!y1_rhs))

# M ~ X + Z | A = 1
m1_rhs <- c(xvars, zvars) %>%
  reduce(~ expr(!!.x + !!.y))
m1_form <- as.formula(expr(!!mvar ~ !!m1_rhs))

# Y ~ X | A = 0
y0_rhs <- xvars %>%
  reduce(~ expr(!!.x + !!.y))
y0_form <- as.formula(expr(!!yvar ~ !!y0_rhs))

# minearn <- 1000
# age <- 29

predsIF <- function(mod, input){
  
  x <- model.matrix(mod)
  w <- mod$weights/mean(mod$weights)
  n <- nrow(x)
  
  term1 <- solve((t(x) %*% diag(w) %*% x)/n) # p * p matrix
  term2 <- t(diag(w * mod$residuals) %*% x) # p * n matrix
  
  IF <- term1 %*% term2
  
  input %*% IF
  
}

# for (j in 2:2){

# load data
nlsy97_full <- nlsy97_nona 

##########################################################
# Loops for DML
##########################################################                       

# number of mi
# I <- length(nlsy97_full)
I <- 1
# number of partitions
S <- 1

# number of cross-fitting folds
K <- 5

# holder for output

overall_log <-
  origin1_log <- gender_origin1_log <-
  origin2_log <- gender_origin2_log <-
  origin1s_log <- gender_origin1s_log <-
  origin2s_log <- gender_origin2s_log <-
  vector(mode = "list", length = I)

# for(i in 1:I){ # just for imputation
# i=1
# cat("imputed sample ", i, "\n")

# create cross-fitting split
df <- nlsy97_full#[[i]]

df1 <- filter(df, att4ycoll20 == 1)
cf_fold <- createFolds(df$povprop, K)

main_list <- vector(mode = "list", K)

#################################################
# Propensity score model for the overall sample
#################################################

df_X <- model.matrix(a_form, data = df)[, -1] %>% as_tibble() # remove intercept

ps_mod <- SuperLearner(
  Y          = df$att4ycoll20,
  X          = df_X,
  family     = binomial(),
  obsWeights = df$weight,
  SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
  # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
  # verbose = T,
  control    = list(saveFitLibrary = TRUE, trimLogit = 0.001),
  cvControl  = list(V = 5L, stratifyCV = TRUE, shuffle = TRUE, validRows = NULL)
)

df$origin2 <- ps_mod$SL.predict

df$origin2s <- ps_mod$SL.predict %>% 
  findInterval(., Hmisc::wtd.quantile(., probs = c(0, 0.2, 0.4, 0.6, 0.8))) %>% 
  ifelse(. == 0, 1, .) %>% 
  factor()

for(k in 1:K){
  # k=1
  cat(" cross-fitting fold ", k, "\n")
  
  #################################################
  # Design Matrices for different models
  #################################################
  
  aux <- df[-cf_fold[[k]], ]
  aux1 <- filter(aux, att4ycoll20 == 1)
  
  # treatment model design matrix
  aux_X <- model.matrix(a_form, data = aux)[, -1] %>% as_tibble()
  df_X <- model.matrix(a_form, data = df)[, -1] %>% as_tibble()
  
  # mediator model design matrix | A = 1 (for estimating M(1))
  aux1_XZ <- model.matrix(m1_form, data = aux1)[, -1] %>% as_tibble()
  df1_XZ <- model.matrix(m1_form, data = df1)[, -1] %>% as_tibble()
  
  # outcome model design matrix (for estimating Y(0,0) and Y(1, M(1)))
  aux_XA <- model.matrix(y_form, data = aux)[, -1] %>% as_tibble()
  df_XAn <- model.matrix(y_form, data = mutate(df, att4ycoll20 = 0))[, -1] %>% as_tibble()
  df_XAy <- model.matrix(y_form, data = mutate(df, att4ycoll20 = 1))[, -1] %>% as_tibble()
  
  # y1 model design matrix | A = 1 (for estimating Y(1,0) and Y(1,1))
  aux1_XZM <- model.matrix(y1_form, data = aux1)[, -1] %>% as_tibble()
  df1_XZMn <- model.matrix(y1_form, data = mutate(df1, compcoll25 = 0))[, -1] %>% as_tibble()
  df1_XZMy <- model.matrix(y1_form, data = mutate(df1, compcoll25 = 1))[, -1] %>% as_tibble()
  
  # nu model design matrix | A = 1
  aux1_X <- model.matrix(a_form, data = aux1)[, -1] %>% as_tibble()
  
  #################################################
  # Treatment model | X
  #################################################
  
  a_mod <- SuperLearner(
    Y          = aux$att4ycoll20,
    X          = aux_X,
    newX       = df_X,
    family     = binomial(),
    obsWeights = aux$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE, trimLogit = 0.001),
    cvControl  = list(V = 5L, stratifyCV = TRUE, shuffle = TRUE, validRows = NULL)
  )
  
  df$a_fit <- a_mod$SL.predict
  
  #################################################
  # Mediator model | A = 1, X, Z
  #################################################
  
  m1_mod <- SuperLearner(
    Y          = aux1$compcoll25,
    X          = aux1_XZ,
    newX       = df1_XZ,
    family     = binomial(),
    obsWeights = aux1$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE, trimLogit = 0.001),
    cvControl  = list(V = 5L, stratifyCV = TRUE, shuffle = TRUE, validRows = NULL)
  )
  
  df1$m1_fit <- m1_mod$SL.predict
  
  #################################################
  # Outcome model for Y(0, 0) and Y(1, M(1)) | X, A
  #################################################
  
  y_mod <- SuperLearner(
    Y          = aux$povprop ,
    X          = aux_XA,
    family     = gaussian(),
    obsWeights = aux$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE),
    cvControl  = list(V = 5L, shuffle = TRUE, validRows = NULL)
  )
  
  
  df$nu00_fit <- predict(y_mod, newdata = df_XAn)$pred
  df$nu1M_fit <- predict(y_mod, newdata = df_XAy)$pred
  
  #################################################
  # Outcome model for Y(1, 0) and Y(1, 1) | X, Z, M
  #################################################
  
  y1_mod <- SuperLearner(
    Y          = aux1$povprop,
    X          = aux1_XZM,
    family     = gaussian(),
    obsWeights = aux1$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE),
    cvControl  = list(V = 5L, shuffle = TRUE, validRows = NULL)
  )
  
  df1$mu10_fit <- predict(y1_mod, newdata = df1_XZMn)$pred
  df1$mu11_fit <- predict(y1_mod, newdata = df1_XZMy)$pred
  
  aux <- left_join(aux, select(df, id, setdiff(names(df), names(aux))), by = "id")
  aux1 <- left_join(aux1, select(df1, id, setdiff(names(df1), names(aux1))), by = "id")
  
  #################################################
  # nu_10(X) = E[mu_10(X,Z)|X, A = 1]
  # nu_11(X) = E[mu_11(X,Z)|X, A = 1]
  #################################################
  
  nu10_mod <- SuperLearner(
    Y          = aux1$mu10_fit,
    X          = aux1_X,
    newX       = df_X,
    family     = gaussian(),
    obsWeights = aux1$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE),
    cvControl  = list(V = 5L, shuffle = TRUE, validRows = NULL)
  )
  
  nu11_mod <- SuperLearner(
    Y          = aux1$mu11_fit,
    X          = aux1_X,
    newX       = df_X,
    family     = gaussian(),
    obsWeights = aux1$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE),
    cvControl  = list(V = 5L, shuffle = TRUE, validRows = NULL)
  )
  
  df$nu10_fit <- nu10_mod$SL.predict
  df$nu11_fit <- nu11_mod$SL.predict
  
  #################################################
  # M(1)|X model
  #################################################
  
  m_mod <- SuperLearner(
    Y          = aux1$compcoll25,
    X          = aux1_X,
    newX       = df_X,
    family     = binomial(),
    obsWeights = aux1$weight,
    SL.library = c("SL.mean", "SL.glmnet", "SL.ranger"),
    # SL.library = c("SL.mean", "SL.glmnet", "SL.grf"),
    control    = list(saveFitLibrary = TRUE, trimLogit = 0.001),
    cvControl  = list(V = 5L, stratifyCV = TRUE, shuffle = TRUE, validRows = NULL)
  )
  
  df$m_fit <- m_mod$SL.predict
  
  #################################################
  # Merge df and df1, extract estimation sample
  #################################################
  df <- left_join(df, select(df1, id, setdiff(names(df1), names(df))), by = "id")
  
  main_list[[k]] <- df[cf_fold[[k]], ]
}

#############################
# Construct rEIFs
#############################

main_df <- reduce(main_list, bind_rows) %>%
  # mutate(weight=1) %>% 
  mutate(
    ps = a_fit,
    y00_eif = nu00_fit + (1 - att4ycoll20)/(1 - a_fit) * (povprop - nu00_fit),
    y1M_eif = nu1M_fit + att4ycoll20/a_fit * (povprop - nu1M_fit),
    y10_eif = ifelse(att4ycoll20 == 1,
                     nu10_fit + 1/a_fit * (mu10_fit - nu10_fit) +
                       (1 - compcoll25)/a_fit/(1-m1_fit) * (povprop - mu10_fit),
                     nu10_fit),
    y11_eif = ifelse(att4ycoll20 == 1,
                     nu11_fit + 1/a_fit * (mu11_fit - nu11_fit) +
                       compcoll25/a_fit/m1_fit * (povprop - mu11_fit),
                     nu11_fit),
    ate_eif = y1M_eif - y00_eif,
    cde_eif = y10_eif - y00_eif,
    cme_eif = y11_eif - y10_eif,
    aje_eif = y11_eif - y00_eif,
    atm_eif = m_fit + att4ycoll20/a_fit * (compcoll25 - m_fit),
    nie_eif = ate_eif - cde_eif,
    cov_eif = nie_eif - wtd.mean(atm_eif, weight) * cme_eif - wtd.mean(cme_eif, weight) * atm_eif +
      wtd.mean(atm_eif, weight) * wtd.mean(cme_eif, weight)
  )

#################################################
# rEIF regressions
#################################################
design <- svydesign(ids = ~ 1, weights = ~ weight, data = main_df)
depvars <- select(main_df, ends_with("_eif")) %>% names()

overall_mods <- map(depvars, ~ svyglm(as.formula(expr(!!sym(.x) ~ 1)), design = design)) 

############################
# Output
############################

# overall
overall <- overall_mods %>%
  set_names(str_sub(depvars, end = -5)) %>%
  enframe(name = "estimand", value = "model") %>%
  mutate(est = map(model, coef),
         vcov = map(model, vcov),
         se = map(vcov, ~ sqrt(diag(.x)))) %>%
  select(estimand, est, se) %>%
  unnest(c(est, se))

overall_log_df <- overall %>% 
  rename(coef_est = est,
         coef_se = se)
all_outcomes <- overall_log_df %>% 
  filter(str_starts(estimand, "y"))
all_effects <- overall_log_df %>% 
  filter(!str_starts(estimand, "y"))

table1 <- all_effects %>% 
  mutate_at(vars(coef_est, coef_se), ~ formatC(.x, format = "f", digits = 2)) %>% 
  transmute(estimand, estimate = paste0(coef_est, " (", coef_se, ")")) %>% 
  # subset(., estimand %in% c("ate", "cde", "nie", "atm", "cme", "cov")) %>% 
  # mutate(estimand = factor(estimand, levels = c("ate", "cde", "nie", "atm", "cme", "cov"))) %>% 
  arrange(estimand) %>% 
  pivot_wider(names_from = estimand, values_from = estimate)
table1