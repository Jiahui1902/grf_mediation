# load NLSY 97 data and remove 46 observations when att == 0 & comp == 1

# rm(list = ls())
# load packages ------------
library("grf")
library("tidyverse")
library("magrittr")
library("haven")
library("data.table")
select <- dplyr::select
set.seed(12345)

# load self-defined function: adding grf regression forest to superlearner------------
if(Sys.info()["user"]=="jiahuixu"){
  setwd("/Users/jiahuixu/Dropbox/_research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="xujiahui"){
  setwd("/Users/xujiahui/Dropbox/_research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}
if(Sys.info()["user"]=="jpx5053"){
  setwd("/storage/work/jpx5053/research/grf_mediation")
  source("./codes/Lrnr_regressionforest.R",encoding = "utf-8")
}

# load NLSY 97 data ---------
# outcome: pov, povprop
# treatment: att4ycoll20
# mediator: compcoll25
nlsy97_full <- read_dta("workingdata/edurose97_socioeconomicoutcomes_20211226.dta")
nlsy97_full$id <- nlsy97_full$R0000100
# data is from 1997 to 2019

# R is 12-16 years old at survey beginning
y <- function(x){
  i=x%/%100
  i=ifelse(i==97,1997,i)
  i=ifelse(i==98,1998,i)
  i=ifelse(i==99,1999,i)
  i
}
emp <- function(value){
  nlsy97_full %>% 
    select(age,contains("E00130")) %>% 
    mutate(across(contains("E00130"),y),
           age=1997-age+value) %>% 
    apply(.,1,function(i){sum(i[-1]==i[1])})
}

# mediators: employment status (3 different measures)
# 1. employment status as age 22 or age 21
nlsy97_full$empstatus_20 <- emp(20)
nlsy97_full$empstatus_21 <- emp(21)
nlsy97_full$empstatus_22 <- emp(22)
nlsy97_full$empstatus_23 <- emp(23)
nlsy97_full$empstatus_24 <- emp(24)
nlsy97_full$empstatus_25 <- emp(25)
# 2. proportion of time being employed between age 20 and age 25
nlsy97_full$propemp2025 <- (nlsy97_full %>%
  select(contains("empstatus_2")) %>% rowSums())/(52)

# 3. working weeks between age 20 and age 25
nlsy97_full$timeemp2025 <- (nlsy97_full %>%
  select(contains("empstatus_2")) %>% rowSums())

## listwise delete NAs in outcome, treatment, mediator, and confounders ----
nlsy97_nona <- nlsy97_full %>%
  dplyr::select(id,att4ycoll20,compcoll25,pov,povprop,male,black,hisp,i_daded,
                i_momed,i_parinc,i_intact,i_sibsz,i_rural,i_south,i_abil,good,
                i_gpa,i_hsprog,i_schsafe,i_tchgd,i_freduasp,i_delinq,i_mar18,
                i_parent18,propemp2025,timeemp2025,propsc_att20lin) %>%
  na.omit()
### remove cases when att == 0 & comp == 1 
nlsy97_nona%>%select(att4ycoll20,compcoll25) %>% table
nlsy97_nona <- nlsy97_nona%>%filter(!(att4ycoll20==0&compcoll25==1))
grf_slides <- nlsy97_nona
nlsy97_nona <- left_join(nlsy97_nona,nlsy97_full)
nlsy97_nona$weight <- 1 # without adding sampling weight
nlsy97_nona %>% dim # 6907


X <- nlsy97_nona %>%
  dplyr::select(male,black,hisp,i_daded,
                i_momed,i_parinc,i_intact,i_sibsz,i_rural,i_south,i_abil,good,
                i_gpa,i_hsprog,i_schsafe,i_tchgd,i_freduasp,i_delinq,i_mar18,
                i_parent18,propsc_att20lin) %>%
  as.data.frame
Y <- nlsy97_nona$povprop %>% as.vector()
W <- nlsy97_nona$att4ycoll20 %>% as.vector()
W_comp <- nlsy97_nona$compcoll25 %>% as.vector()
