library(optparse)
library("TeachingDemos")
library(stringr)
library(grf)

option_list <- list(
	make_option("--v", default="version1"),
	make_option("--loov", default=1)
)
opts <- parse_args(OptionParser(option_list=option_list))
testversion <- opts$v
loov <- as.numeric(opts$loov)
print(loov)

source("./codes/02_load_data.R")

df_result = vector(mode = "list",length=10)
l = ((10*(loov-1)+1):(10*loov))
if (loov == 691){
    l = 6901:6907
    df_result = vector(mode = "list",length=7)
}

sink(file = paste0("./workingdata/loov_97/97_leave_one_out_prediction",loov,".txt"))
for(i in l ){
  med = med_causal_forest(as.matrix(X[-i,]),Y[-i],W = as.factor(W[-i]),M = as.vector(W_comp[-i]),num.trees=4000,min.node.size=20)  
  cf = causal_forest(as.matrix(X[-i,]),Y[-i], W[-i], num.trees = 2000)
  
  fit = c(ate = predict(cf,X[i,])$predictions, 
                     nde = predict(med,X[i,])$predictions[,,1],
                     nie = predict(med$nie.forest,X[i,])$predictions[,,1] )
  cat(c(i, fit))
  cat("\n")
  df_result[[i]] = fit
  
  if (i %% 10 == 0){
  gc()
  }
}
sink()

df_result %>% bind_rows %>% colMeans(.,na.rm=TRUE)
