# step 1: install the customized version of grf from GitHub: https://github.com/Jiahui1902/grf_mediation.git

## in this customized grf package, we added the causal mediation forest algorithm
## change pathname before running the code
install.packages("/storage/work/jpx5053/research/grf_mediation/packages/grf_2.4.5.tar.gz", 
  repos = NULL, 
  type = "source")

## to remove the package, run the following
# remove.packages("grf")

