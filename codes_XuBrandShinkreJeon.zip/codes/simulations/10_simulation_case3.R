
# setup
library(pbapply)
library(stringr)
library(tidyverse)
library(grf)
packageVersion("grf")
library("TeachingDemos")


txtStart("_output/simulation_case3.txt")

Sys.time()

txtComment("=========================================")
txtComment("Case 3")
txtComment("=========================================")

set.seed(42)
N = 10000
x1 = runif(N,-1,1)
x2 = runif(N,-1,1)
x3 = runif(N,-1,1)
x4 = runif(N,-1,1)
x5 = runif(N,-1,1)
x6 = runif(N,-1,1) # heterogeneity variable

hnde = case_when(x6 > 0 & x6<0.6 ~ x6, 
                x6 >=0.6~ -x6,
                TRUE ~ 3*x6)
hnie = rep(.5,N)

err1 = rnorm(N, 0, 1) # for Y
err2 = rnorm(N, 0, 1) # for mediator (college completion)

# covariates
X = cbind(x1, x2, x3, x4, x5, x6)
# treatment
a <- Vectorize(function(x) {
    d0 = data.frame(c1 = x1[x]*x2[x], c2 = x3[x]*x4[x]*x5[x], 
                    c3 = sin(x1[x])*sin(x2[x]), c4 = sin(x3[x])*sin(x4[x])*sin(x5[x]))
    d1 = data.frame(a1 = sin(d0$c1 + d0$c2), a2 = sin(d0$c2), a3 = d0$c3, a4 = d0$c4)
    d2 = 0.5*sin(d1$a1 + d1$a2) + 0.5*(d1$a3 + d1$a4)
    1/( 1 + exp(-d2) )
}, vectorize.args = "x")
A <- rbinom(N, size = 1, prob = a(1:N))

# mediator
mx = 4*(sin(3*x1)+sin(3*x2)+sin(3*x3)+sin(3*x4)+sin(3*x5))
theta_ma = 2
m <- function(ia=A,x) {
    l1 = theta_ma*ia[x] + mx[x] + err2[x]        
    l1
}
M = m(ia=A,1:N)

# outcome
y0 = data.frame(x1 = sin(x1+x2), x2 = sin(x3+x4+x5), x3 = sin(x1+x2+x3+x4+x5))
y1 = data.frame(x1 = sin(y0$x1 + y0$x2), x2 = y0$x3)
y2 = 2*sin(y1$x2 + y1$x2)
Y = hnde*A + hnie*M + y2 + err1

# TRUE
MA = Vectorize(function(x) {m(ia=A,x)*hnie[x]},vectorize.args = "x")
M1 = Vectorize(function(x) {m(ia=rep(1,N),x)*hnie[x]},vectorize.args = "x")
M0 = Vectorize(function(x) {m(ia=rep(0,N),x)*hnie[x]},vectorize.args = "x")

cat("tot")
mean(hnde+(M1(1:N)-M0(1:N)))
cat("nde")
mean(hnde)
cat("nie")
mean(M1(1:N)-M0(1:N))

# total effect
cf = causal_forest(X,Y,A)
average_treatment_effect(cf)
cf$predictions %>% mean

## no clever variable
med = med_causal_forest(X,Y,W = as.factor(A),M = as.vector(M),num.trees=4000,min.node.size=20)
med_summary_effect(med)
med$nde %>% mean
med$nie %>% mean
med$nde %>% summary
med$nie %>% summary

source("/storage/home/jpx5053/work/research/grf_mediation/codes/Lrnr_regressionforest.R")
df_full = data.frame(Y = Y, x1 = x1, x2 = x2, x3 = x3, x4 = x4, x5 = x5,x6=x6, A = A, M = M)
df_full$weight = 1
df_full$id = 1:N
xvars <- rlang::exprs(x1,x2,x3,x4,x5,x6)
source("/storage/home/jpx5053/work/research/grf_mediation/codes/Zhou_simulaltioncodes_add_continuous.R")
overall


df = data.frame(id = 1:N,
                ax1 = x6,
                true_ate = hnde + (M1(1:N)-M0(1:N)), true_nde = hnde, 
                true_nie = M1(1:N)-M0(1:N), 
                est_ate = cf$predictions, est_nde = med$nde,                 
                est_nie = med$nie)
df_plot = left_join(df,main_df %>% select(id,ate_eif,tde_eif, tie_eif,cde_eif,nie_eif))
df_plot$ax1_bin = cut(df_plot$ax1,quantile(df_plot$ax1,0:100/100),include.lowest=TRUE) %>% as.numeric


ax1_plot = df_plot %>% 
    group_by(ax1_bin) %>%
    summarize(x1       = mean(x1),
              true_ate = mean(true_ate),
              true_nde = mean(true_nde),
              true_nie = mean(true_nie),
              grf_ate  = mean(est_ate),
              grf_nde  = mean(est_nde),
              grf_nie  = mean(est_nie),
              dml_ate  = mean(ate_eif,na.rm=TRUE),
              dml_nde  = mean(tde_eif,na.rm=TRUE),
              dml_nie  = mean(tie_eif,na.rm=TRUE),
              diff_ate_grf = grf_ate - true_ate,
              diff_nde_grf = grf_nde - true_nde,
              diff_nie_grf = grf_nie - true_nie,
              diff_ate_dml = dml_ate - true_ate,
              diff_nde_dml = dml_nde - true_nde,
              diff_nie_dml = dml_nie - true_nie,
              )

p1 = ggplot(ax1_plot)+
    geom_point(mapping = aes(x = ax1_bin,y=true_ate,color="Truth"))+
    geom_point(mapping = aes(x = ax1_bin,y=grf_ate,color="GRF"))+
    geom_point(mapping = aes(x = ax1_bin,y=dml_ate,color="DML"))+
    scale_color_manual(name=NULL,breaks=c("Truth","GRF","DML"),values=c("black","red","blue"))+
    theme_bw()+
    labs(x = "Percentile of X",y="Total Treatment Effect")

p2 = ggplot(ax1_plot)+
    geom_point(mapping = aes(x = ax1_bin,y=true_nde,color="Truth"))+
    geom_point(mapping = aes(x = ax1_bin,y=grf_nde,color="GRF"))+
    geom_point(mapping = aes(x = ax1_bin,y=dml_nde,color="DML"))+
    scale_color_manual(name=NULL,breaks=c("Truth","GRF","DML"),values=c("black","red","blue"))+
    theme_bw()+
    labs(x = "Percentile of X",y="Natural Direct Effect")

p3 = ggplot(ax1_plot)+
    geom_point(mapping = aes(x = ax1_bin,y=true_nie,color="Truth"))+
    geom_point(mapping = aes(x = ax1_bin,y=grf_nie,color="GRF"))+
    geom_point(mapping = aes(x = ax1_bin,y=dml_nie,color="DML"))+
    scale_color_manual(name=NULL,breaks=c("Truth","GRF","DML"),values=c("black","red","blue"))+
    theme_bw()+
    labs(x = "Percentile of X",y="Natural Indirect Effect")
g=ggpubr::ggarrange(p1,p2,p3,nrow=1,ncol=3,common.legend=TRUE,legend="bottom")
ggsave("_output/simulation_case3.pdf",plot=g,width=18,height=6)



library(medoutcon)
txtComment("=========================================")

# =====================================
# Diaz (2021) DML + interventional 
# approach ATE, IDE, NIE
# =====================================

educ_nde_os_noz = medoutcon(W = X,
                     A = A,
                     Z = NULL,
                     M = M,
                     Y = Y,
                     effect = "direct",
                     estimator = "onestep")
educ_nde_os_noz
educ_nde_os_noz %>% summary
educ_nde_os_noz %>% summary %>% .$param_est 
educ_nde_os_noz %>% summary %>% .$var_est %>% sqrt


educ_nie_os_noz = medoutcon(W = X,
                     A = A,
                     Z = NULL,
                     M = M,
                     Y = Y,
                     effect = "indirect",
                     estimator = "onestep")
educ_nie_os_noz
educ_nie_os_noz %>% summary
educ_nie_os_noz %>% summary %>% .$param_est 
educ_nie_os_noz %>% summary %>% .$var_est %>% sqrt

txtComment("=========================================")

# =====================================
# Diaz (2021) DML + interventional 
# TMLE with medoutcon
# =====================================
educ_nde_tmle_noz = medoutcon(W = X,
                     A = A,
                     Z = NULL,
                     M = M,
                     Y = Y,
                     effect = "direct",
                     estimator = "tmle")
educ_nde_tmle_noz
educ_nde_tmle_noz %>% summary
educ_nde_tmle_noz %>% summary %>% .$param_est 
educ_nde_tmle_noz %>% summary %>% .$var_est %>% sqrt


educ_nie_tmle_noz = medoutcon(W = X,
                     A = A,
                     Z = NULL,
                     M = M,
                     Y = Y,
                     effect = "indirect",
                     estimator = "tmle")
educ_nie_tmle_noz
educ_nie_tmle_noz %>% summary
educ_nie_tmle_noz %>% summary %>% .$param_est 
educ_nie_tmle_noz %>% summary %>% .$var_est %>% sqrt

Sys.time()
txtStop()