# Super Learner wrapper for grf -----
SL.grf <- function (Y, X, newX, family, obsWeights, num.trees = 2000, mtry = floor(sqrt(ncol(X))), 
                    write.forest = TRUE, probability = family$family == "binomial", 
                    min.node.size = ifelse(family$family == "gaussian", 5, 1), 
                    replace = TRUE, sample.fraction = ifelse(replace, 1, 0.632), 
                    num.threads = 1, verbose = T, ...) 
{
  if (family$family == "binomial") {
    Y = as.vector(Y)
  }
  if (is.matrix(X)) {
    X = data.frame(X)
  }
  Y = as.vector(Y)
  X = as.data.frame(X)
  fit <- grf::regression_forest(X=X, Y=Y,sample.weights=obsWeights,num.trees=num.trees,
                                mtry=mtry)
  pred <- predict(fit, newX)$predictions
  pred = pred
  fit <- list(object = fit, verbose = verbose)
  class(fit) <- c("SL.grf")
  out <- list(pred = pred, fit = fit)
  return(out)
}
predict.SL.grf <- function (object, newdata, family, num.threads = 1, verbose = object$verbose, 
          ...) 
{
  pred <- predict(object$object, newdata)$predictions
  pred
}

# regression forest -------
Lrnr_regressionforest <- R6::R6Class(
  classname = "Lrnr_regressionforest",
  inherit = Lrnr_base, portable = TRUE, class = TRUE,
  public = list(
    initialize = function(num.trees = 2000,
                          sample.weights = NULL,
                          clusters = NULL,
                          equalize.cluster.weights = FALSE,
                          sample.fraction = 0.5,
                          mtry = NULL,
                          min.node.size = 5,
                          honesty = TRUE,
                          honesty.fraction = 0.5,
                          honesty.prune.leaves = TRUE,
                          alpha = 0.05,
                          imbalance.penalty = 0,
                          ci.group.size = 2,
                          tune.parameters = "none",
                          tune.num.trees = 50,
                          tune.num.reps = 100,
                          tune.num.draws = 1000,
                          compute.oob.predictions = TRUE,
                          num.threads = 1L,
                          ...) {
      super$initialize(params = args_to_list(), ...)
    }
  ),
  private = list(
    .properties = c("continuous", "binomial", "categorical", "weights"),
    .train = function(task) {
      args <- self$params
      outcome_type <- self$get_outcome_type(task)
      
      # specify data
      args$X <- as.data.frame(task$X)
      args$Y <- outcome_type$format(task$Y)
      
      if (task$has_node("weights")) {
        args$weights <- task$weights
      }
      
      if (task$has_node("offset")) {
        args$offset <- task$offset
      }
      
      # set mtry arg based on dimensionality of X to match grf::quantile_forest
      if (is.null(args$mtry)) {
        args$mtry <- min(ceiling(sqrt(ncol(args$X)) + 20), ncol(args$X))
      }
      
      # train via call_with_args and return fitted object
      # fit_object <- call_with_args(grf::regression_forest, args)
      fit_object <- rlang::exec(grf::regression_forest, !!!args)
      return(fit_object)
    },
    .predict = function(task) {
      # quantiles for which to predict
      quantiles_pred <- private$.params$quantiles_pred
      
      # generate predictions and output
      predictions_list <- stats::predict(
        private$.fit_object,
        new_data = data.frame(task$X),
        quantiles = quantiles_pred
      )
      predictions <- as.numeric(predictions_list$predictions)
      return(predictions)
    },
    .required_packages = c("grf")
  )
)


# multi regression forest -------
Lrnr_mulregressionforest <- R6::R6Class(
  classname = "Lrnr_mulregressionforest",
  inherit = Lrnr_base, portable = TRUE, class = TRUE,
  public = list(
    initialize = function(num.trees = 2000,
                          sample.weights = NULL,
                          clusters = NULL,
                          equalize.cluster.weights = FALSE,
                          sample.fraction = 0.5,
                          mtry = NULL,
                          min.node.size = 5,
                          honesty = TRUE,
                          honesty.fraction = 0.5,
                          honesty.prune.leaves = TRUE,
                          alpha = 0.05,
                          imbalance.penalty = 0,
                          compute.oob.predictions = TRUE,
                          num.threads = 1L,
                          ...) {
      super$initialize(params = args_to_list(), ...)
    }
  ),
  private = list(
    .properties = c("continuous", "binomial", "categorical", "weights"),
    .train = function(task) {
      args <- self$params
      outcome_type <- self$get_outcome_type(task)
      
      # specify data
      args$X <- as.data.frame(task$X)
      args$Y <- outcome_type$format(task$Y)
      
      if (task$has_node("weights")) {
        args$weights <- task$weights
      }
      
      if (task$has_node("offset")) {
        args$offset <- task$offset
      }
      
      # set mtry arg based on dimensionality of X to match grf::quantile_forest
      if (is.null(args$mtry)) {
        args$mtry <- min(ceiling(sqrt(ncol(args$X)) + 20), ncol(args$X))
      }
      
      # train via call_with_args and return fitted object
      # fit_object <- call_with_args(grf::regression_forest, args)
      fit_object <- rlang::exec(grf::multi_regression_forest, !!!args)
      return(fit_object)
    },
    .predict = function(task) {
      # quantiles for which to predict
      quantiles_pred <- private$.params$quantiles_pred
      
      # generate predictions and output
      predictions_list <- stats::predict(
        private$.fit_object,
        new_data = data.frame(task$X),
        quantiles = quantiles_pred
      )
      predictions <- as.numeric(predictions_list$predictions)
      return(predictions)
    },
    .required_packages = c("grf")
  )
)


# ll regression forest -------
Lrnr_llregressionforest <- R6::R6Class(
  classname = "Lrnr_llregressionforest",
  inherit = Lrnr_base, portable = TRUE, class = TRUE,
  public = list(
    initialize = function(enable.ll.split = FALSE,
                          ll.split.weight.penalty = FALSE,
                          ll.split.lambda = 0.1,
                          ll.split.variables = NULL,
                          ll.split.cutoff = NULL,
                          num.trees = 2000,
                          clusters = NULL,
                          equalize.cluster.weights = FALSE,
                          sample.fraction = 0.5,
                          mtry = NULL,
                          min.node.size = 5,
                          honesty = TRUE,
                          honesty.fraction = 0.5,
                          honesty.prune.leaves = TRUE,
                          alpha = 0.05,
                          imbalance.penalty = 0,
                          ci.group.size = 2,
                          tune.parameters = "none",
                          tune.num.trees = 50,
                          tune.num.reps = 100,
                          tune.num.draws = 1000,
                          num.threads = 1L,
                          ...) {
      super$initialize(params = args_to_list(), ...)
    }
  ),
  private = list(
    .properties = c("continuous", "binomial", "categorical", "weights"),
    .train = function(task) {
      args <- self$params
      outcome_type <- self$get_outcome_type(task)
      
      # specify data
      args$X <- as.data.frame(task$X)
      args$Y <- outcome_type$format(task$Y)
      
      if (task$has_node("weights")) {
        args$weights <- task$weights
      }
      
      if (task$has_node("offset")) {
        args$offset <- task$offset
      }
      
      # set mtry arg based on dimensionality of X to match grf::quantile_forest
      if (is.null(args$mtry)) {
        args$mtry <- min(ceiling(sqrt(ncol(args$X)) + 20), ncol(args$X))
      }
      
      # train via call_with_args and return fitted object
      # fit_object <- call_with_args(grf::regression_forest, args)
      fit_object <- rlang::exec(grf::ll_regression_forest, !!!args)
      return(fit_object)
    },
    .predict = function(task) {
      # quantiles for which to predict
      quantiles_pred <- private$.params$quantiles_pred
      
      # generate predictions and output
      predictions_list <- stats::predict(
        private$.fit_object,
        new_data = data.frame(task$X),
        quantiles = quantiles_pred
      )
      predictions <- as.numeric(predictions_list$predictions)
      return(predictions)
    },
    .required_packages = c("grf")
  )
)


# boosted regression forest -------
Lrnr_boostedregressionforest <- R6::R6Class(
  classname = "Lrnr_boostedregressionforest",
  inherit = Lrnr_base, portable = TRUE, class = TRUE,
  public = list(
    initialize = function(num.trees = 2000,
                          sample.weights = NULL,
                          clusters = NULL,
                          equalize.cluster.weights = FALSE,
                          sample.fraction = 0.5,
                          mtry = NULL,
                          min.node.size = 5,
                          honesty = TRUE,
                          honesty.fraction = 0.5,
                          honesty.prune.leaves = TRUE,
                          alpha = 0.05,
                          imbalance.penalty = 0,
                          ci.group.size = 2,
                          tune.parameters = "none",
                          tune.num.trees = 10,
                          tune.num.reps = 100,
                          tune.num.draws = 1000,
                          boost.steps = NULL,
                          boost.error.reduction = 0.97,
                          boost.max.steps = 5,
                          boost.trees.tune = 10,
                          num.threads = 1L,
                          ...) {
      super$initialize(params = args_to_list(), ...)
    }
  ),
  private = list(
    .properties = c("continuous", "binomial", "categorical", "weights"),
    .train = function(task) {
      args <- self$params
      outcome_type <- self$get_outcome_type(task)
      
      # specify data
      args$X <- as.data.frame(task$X)
      args$Y <- outcome_type$format(task$Y)
      
      if (task$has_node("weights")) {
        args$weights <- task$weights
      }
      
      if (task$has_node("offset")) {
        args$offset <- task$offset
      }
      
      # set mtry arg based on dimensionality of X to match grf::quantile_forest
      if (is.null(args$mtry)) {
        args$mtry <- min(ceiling(sqrt(ncol(args$X)) + 20), ncol(args$X))
      }
      
      # train via call_with_args and return fitted object
      # fit_object <- call_with_args(grf::regression_forest, args)
      fit_object <- rlang::exec(grf::boosted_regression_forest, !!!args)
      return(fit_object)
    },
    .predict = function(task) {
      # quantiles for which to predict
      quantiles_pred <- private$.params$quantiles_pred
      
      # generate predictions and output
      predictions_list <- stats::predict(
        private$.fit_object,
        new_data = data.frame(task$X),
        quantiles = quantiles_pred
      )
      predictions <- as.numeric(predictions_list$predictions)
      return(predictions)
    },
    .required_packages = c("grf")
  )
)
